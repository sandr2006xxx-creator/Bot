"""Точка входа (Amvera: scriptName: main.py)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import asyncio
import logging

from bot.config import require_env

require_env()

from aiogram.types import BotCommand  # noqa: E402

from bot import scheduler  # noqa: E402
from bot.config import DB_FILE, OWNER_ID  # noqa: E402
from bot.data_sources import http  # noqa: E402
from bot.handlers import router  # noqa: E402
from bot.notify import OwnerAlertHandler  # noqa: E402
from bot.runtime import bot, dp  # noqa: E402
from bot.storage import store  # noqa: E402
from bot.utils import now  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s", force=True)
logging.getLogger("apscheduler").setLevel(logging.WARNING)
log = logging.getLogger("bot")


async def on_startup() -> None:
    await store.open()
    await http.start()
    logging.getLogger().addHandler(OwnerAlertHandler(bot))
    await bot.set_my_commands([
        BotCommand(command="start", description="Начать / настроить"),
        BotCommand(command="dz", description="Домашки"),
        BotCommand(command="rem", description="Мои напоминания"),
        BotCommand(command="schedule", description="Моё расписание (ручной ввод)"),
        BotCommand(command="setup", description="Перенастроить"),
        BotCommand(command="settings", description="Настройки и состояние"),
        BotCommand(command="ics", description="Календарь (.ics)"),
        BotCommand(command="help", description="Как пользоваться"),
    ])
    scheduler.start()
    me = await bot.get_me()
    st = await store.admin_stats()
    log.info("@%s запущен | админ %s | база %s | пользователей %s (активных %s) | %s",
             me.username, OWNER_ID, DB_FILE, st["users"], st["active"], now().strftime("%d.%m %H:%M %Z"))


async def on_shutdown() -> None:
    scheduler.shutdown()
    await http.close()
    await store.close()


async def main() -> None:
    dp.include_router(router)
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())

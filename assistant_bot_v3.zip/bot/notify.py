"""Критические ошибки — владельцу в Telegram (с дедупликацией, чтобы не спамить)."""
import asyncio
import logging
import time

from aiogram import html

from .config import OWNER_ID

DEDUP_SECONDS = 600


class OwnerAlertHandler(logging.Handler):
    def __init__(self, bot) -> None:
        super().__init__(level=logging.ERROR)
        self.bot = bot
        self._recent: dict[str, float] = {}

    def emit(self, record: logging.LogRecord) -> None:
        try:
            if getattr(record, "no_alert", False):
                return
            loop = asyncio.get_running_loop()
            msg = record.getMessage()
            key = f"{record.name}:{msg[:120]}"
            t = time.monotonic()
            if t - self._recent.get(key, 0) < DEDUP_SECONDS:
                return
            self._recent[key] = t
            tail = ""
            if record.exc_info and record.exc_info[1] is not None:
                tail = f"\n<code>{html.quote(f'{type(record.exc_info[1]).__name__}: {record.exc_info[1]}'[:600])}</code>"
            text = f"⚠️ <b>Ошибка бота</b> [{record.name}]\n{html.quote(msg[:800])}{tail}"
            loop.create_task(self._send(text))
        except Exception:
            pass

    async def _send(self, text: str) -> None:
        try:
            await self.bot.send_message(OWNER_ID, text)
        except Exception as e:
            logging.getLogger("bot.notify").warning("Не смог отправить алерт: %s", e, extra={"no_alert": True})

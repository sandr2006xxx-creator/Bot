"""Внешние данные: Google Sheets (CSV), Open-Meteo, геокодер. Функции параметризованы профилем пользователя.
Кэш ключуется по URL — пользователи с одной таблицей делят один запрос."""
import asyncio
import csv
import io
import logging
import re
import time
from datetime import date
from typing import Any, Optional

import aiohttp

from .config import DAYS_RU, TTL_UNIVER, TTL_WEATHER, TTL_WORK
from .utils import TIME_RE

log = logging.getLogger("bot.data")
RETRY_DELAYS = (0.5, 2.0)
SHEET_ID_RE = re.compile(r"(?:spreadsheets/d/|^)([A-Za-z0-9_-]{20,})")


def parse_sheet_id(text: str) -> Optional[str]:
    m = SHEET_ID_RE.search(text.strip())
    return m.group(1) if m else None


def csv_url(sheet_id: str) -> str:
    return f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv"


class Http:
    def __init__(self) -> None:
        self.session: Optional[aiohttp.ClientSession] = None
        self.cache: dict[str, tuple[float, Any]] = {}
        self.fails: dict[str, int] = {}
        self.last_error: dict[str, str] = {}

    async def start(self) -> None:
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10),
                                             headers={"User-Agent": "assistant-bot/3.0"})

    async def close(self) -> None:
        if self.session:
            await self.session.close()

    async def _fetch(self, key: str, url: str, params: Optional[dict], ttl: int, parse):
        hit = self.cache.get(key)
        if hit and time.monotonic() - hit[0] < ttl:
            return hit[1]
        attempts = 2 if hit else 3
        for i in range(attempts):
            try:
                async with self.session.get(url, params=params) as r:
                    r.raise_for_status()
                    data = parse(await r.text())
                self.cache[key] = (time.monotonic(), data)
                return data
            except Exception as e:
                self.last_error[key] = f"{type(e).__name__}: {e}"[:200]
                if i + 1 < attempts:
                    await asyncio.sleep(RETRY_DELAYS[min(i, len(RETRY_DELAYS) - 1)])
        self.fails[key] = self.fails.get(key, 0) + 1
        log.warning("Не удалось загрузить %s (%s); отдаю кэш: %s", key, self.last_error.get(key), bool(hit))
        return hit[1] if hit else None

    async def rows(self, url: str, ttl: int) -> Optional[list[list[str]]]:
        return await self._fetch(url, url, None, ttl, lambda t: list(csv.reader(io.StringIO(t))))

    async def json(self, url: str, params: dict, ttl: int) -> Optional[dict]:
        import json as _json
        key = url + "?" + "&".join(f"{k}={v}" for k, v in sorted(params.items()))
        return await self._fetch(key, url, params, ttl, _json.loads)

    def cache_age(self, key: str) -> Optional[int]:
        hit = self.cache.get(key)
        return int(time.monotonic() - hit[0]) if hit else None


http = Http()


async def work_rows(sheet_id: Optional[str]):
    return await http.rows(csv_url(sheet_id), TTL_WORK) if sheet_id else None


async def univ_rows(sheet_id: Optional[str]):
    return await http.rows(csv_url(sheet_id), TTL_UNIVER) if sheet_id else None


async def probe_sheet(sheet_id: str) -> tuple[bool, str]:
    """Проверка при онбординге: таблица доступна по ссылке и не пустая."""
    rows = await http.rows(csv_url(sheet_id), 0)
    if rows is None:
        return False, http.last_error.get(csv_url(sheet_id), "не скачалась")
    if len(rows) < 2:
        return False, "таблица пустая"
    return True, f"строк: {len(rows)}"


async def fetch_weather(lat: Optional[float], lon: Optional[float]) -> Optional[dict]:
    if lat is None or lon is None:
        return None
    return await http.json("https://api.open-meteo.com/v1/forecast", {
        "latitude": round(lat, 3), "longitude": round(lon, 3),
        "current": "temperature_2m,apparent_temperature,precipitation,wind_speed_10m",
        "daily": "temperature_2m_min,temperature_2m_max,snowfall_sum,precipitation_sum",
        "wind_speed_unit": "ms", "timezone": "Europe/Moscow", "forecast_days": 2,
    }, TTL_WEATHER)


async def geocode(city: str) -> Optional[tuple[str, float, float]]:
    data = await http.json("https://geocoding-api.open-meteo.com/v1/search",
                           {"name": city.strip(), "count": 1, "language": "ru"}, 24 * 3600)
    if not data or not data.get("results"):
        return None
    r = data["results"][0]
    name = r.get("name", city) + (f", {r['admin1']}" if r.get("admin1") else "")
    return name, float(r["latitude"]), float(r["longitude"])


# ---------- разбор таблиц ----------
def shift_info(rows: Optional[list[list[str]]], day: date, surname: Optional[str]) -> tuple[str, Optional[str]]:
    """("work", "HH:MM") | ("off", None) | ("other", текст) | ("error", причина)."""
    if rows is None:
        return "error", "график не загрузился"
    if len(rows) < 2:
        return "error", "график пустой"
    if not surname:
        return "error", "не указана фамилия"
    wanted = str(day.day)
    col = next((i for i, h in enumerate(rows[0]) if h.strip().split()[:1] == [wanted]), -1)
    if col == -1:
        return "error", f"в графике нет столбца «{wanted}»"
    s = surname.lower()
    for row in rows[1:]:
        if any(s in c.lower() for c in row[:3]):
            cell = row[col].strip() if col < len(row) else ""
            if not cell or cell.upper() == "В":
                return "off", None
            times = TIME_RE.findall(cell)
            if times:
                h, m = times[-1]
                return "work", f"{int(h):02d}:{m}"
            return "other", cell
    return "error", f"в графике не найдена фамилия {surname}"


def week_name(day: date, semester_start: Optional[str], starts_plus: bool) -> tuple[bool, str]:
    if not semester_start:
        return True, ""
    weeks = (day - date.fromisoformat(semester_start)).days // 7
    is_plus = (weeks % 2 == 0) == bool(starts_plus)
    return is_plus, "➕ плюс" if is_plus else "➖ минус"


def schedule_from_rows(rows: Optional[list[list[str]]], day: date, semester_start: Optional[str],
                       starts_plus: bool) -> Optional[str]:
    """Текст пар на день, '' если пар нет, None если таблица недоступна."""
    if rows is None:
        return None
    is_plus, _ = week_name(day, semester_start, starts_plus)
    col = 1 if is_plus else 2
    wanted = DAYS_RU[day.weekday()].lower()
    for row in rows:
        if row and row[0].strip().lower() == wanted:
            return row[col].strip() if len(row) > col else ""
    return ""


# ---------- ручное расписание из базы ----------
def schedule_from_db(entries: list[dict], day: date, semester_start: Optional[str], starts_plus: bool) -> str:
    is_plus, _ = week_name(day, semester_start, starts_plus)
    parity = "plus" if is_plus else "minus"
    todays = [e for e in entries if e["weekday"] == day.weekday() and e["parity"] in (None, parity)]
    todays.sort(key=lambda e: e["start"] or "")
    return "\n".join((f"{e['start']} " if e["start"] else "") + e["text"] for e in todays)


def shift_from_db(entries: list[dict], day: date) -> tuple[str, Optional[str]]:
    iso = day.isoformat()
    for e in entries:
        if e["date"] == iso:
            if e["end"]:
                return "work", e["end"]
            return ("off", None) if e["text"].lower() in ("в", "выходной") else ("other", e["text"])
    return "off", None

"""Планировщик: тик по всем активным пользователям. Источник истины — база (catch-up после рестарта)."""
import asyncio
import logging
from datetime import datetime

from aiogram.exceptions import TelegramForbiddenError
from aiogram.types import FSInputFile
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from .config import (BACKUP_DIR, BACKUP_KEEP, BACKUP_TIME, BACKUP_TO_TELEGRAM, CATCHUP, OWNER_ID, SEND_BATCH,
                     SEND_BATCH_PAUSE, TICK_SECONDS, TZ)
from .runtime import bot
from .services import (build_evening, build_summary, fire_timed, remember_after_shift, send_hw_reminder,
                       send_long, shift_for)
from .storage import store
from .utils import at, now

log = logging.getLogger("bot.scheduler")
scheduler = AsyncIOScheduler(timezone=TZ)


async def deactivate(uid: int, why: str) -> None:
    await store.update_user(uid, active=False)
    log.info("Пользователь %s отключён: %s", uid, why)


async def tick_user(u: dict) -> None:
    uid = u["user_id"]
    t = now()
    today = t.date().isoformat()
    sent = await store.uget(uid, "sent", {})
    try:
        for kind in ("morning", "evening"):
            due = at(t.date(), u[kind])
            if t >= due and sent.get(kind) != today and t - due <= CATCHUP:
                text, kb = await (build_summary(u, include_tomorrow=False) if kind == "morning" else build_evening(u))
                await send_long(uid, text, kb)
                sent[kind] = today
                await store.uset(uid, "sent", sent)

        if u["work_mode"] != "none":
            a = await store.uget(uid, "after_shift")
            hour_key = t.strftime("%Y-%m-%d %H")
            if (not a or a.get("date") != today) and sent.get("shift_check") != hour_key:
                sent["shift_check"] = hour_key
                await store.uset(uid, "sent", sent)
                await remember_after_shift(uid, await shift_for(u, t.date()), t.date())
                a = await store.uget(uid, "after_shift")
            if a and not a.get("sent") and t >= datetime.fromisoformat(a["due"]):
                if t - datetime.fromisoformat(a["due"]) <= CATCHUP:
                    await send_hw_reminder(uid, "🔔 Смена закончилась — вот что висит по учёбе:")
                a["sent"] = True
                await store.uset(uid, "after_shift", a)
    except TelegramForbiddenError:
        await deactivate(uid, "заблокировал бота")


async def tick() -> None:
    users = await store.active_users()
    for i in range(0, len(users), SEND_BATCH):
        batch = users[i:i + SEND_BATCH]
        results = await asyncio.gather(*(tick_user(u) for u in batch), return_exceptions=True)
        for u, r in zip(batch, results):
            if isinstance(r, Exception):
                log.error("tick_user %s: %r", u["user_id"], r, exc_info=r)
        if i + SEND_BATCH < len(users):
            await asyncio.sleep(SEND_BATCH_PAUSE)

    for r in await store.due_timed(now()):
        u = await store.user(r["user_id"])
        if not u or not u["active"]:
            await store.update_timed(r["id"], status="cancelled")
            continue
        try:
            await fire_timed(u, r)
        except TelegramForbiddenError:
            await deactivate(u["user_id"], "заблокировал бота")
        except Exception:
            log.exception("Не отправилось напоминание %s", r["id"])
            tries = r.get("tries", 0) + 1
            await store.update_timed(r["id"], tries=tries, **({"status": "failed"} if tries >= 5 else {}))


async def daily_backup() -> None:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    path = BACKUP_DIR / f"bot-{now():%Y%m%d}.sqlite"
    await store.backup(path)
    st = await store.admin_stats()
    caption = (f"🗄 Бэкап {now():%d.%m.%Y}. Пользователей: {st['users']}, активных: {st['active']}, "
               f"новых за неделю: {st['new_week']}.")
    if BACKUP_TO_TELEGRAM:
        await bot.send_document(OWNER_ID, FSInputFile(path), caption=caption, disable_notification=True)
    else:
        await bot.send_message(OWNER_ID, caption + f" Файл: {path.name} (локально).", disable_notification=True)
    for old in sorted(BACKUP_DIR.glob("bot-*.sqlite"))[:-BACKUP_KEEP]:
        old.unlink(missing_ok=True)
    await store.set("last_backup", now().isoformat())


def start() -> None:
    scheduler.add_job(tick, "interval", seconds=TICK_SECONDS, id="tick", max_instances=1, coalesce=True,
                      misfire_grace_time=TICK_SECONDS * 2)
    h, m = map(int, BACKUP_TIME.split(":"))
    scheduler.add_job(daily_backup, "cron", hour=h, minute=m, id="backup", misfire_grace_time=3600, coalesce=True)
    scheduler.start()


def shutdown() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)

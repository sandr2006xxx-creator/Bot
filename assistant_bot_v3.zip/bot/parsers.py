"""Разбор текста: срок «до 15.10», время для «Напомни …», упоминание ДЗ."""
import re
from datetime import date, timedelta
from typing import Optional

from .config import MONTHS_GEN
from .utils import at, fmt_dt, now

DATE_RE = re.compile(r"\s+до\s+(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?\s*$", re.I)

WD_FORMS = {"понедельник": 0, "вторник": 1, "среду": 2, "среда": 2, "четверг": 3,
            "пятницу": 4, "пятница": 4, "субботу": 5, "суббота": 5, "воскресенье": 6}
REL_RE = re.compile(r"\bчерез\s+(?:(\d{1,4})\s*)?(полчаса|минуту|минуты|минут|мин|часа|часов|час|ч|сутки|дня|дней|день)(?![а-яё])\.?", re.I)
CLOCK_COLON_RE = re.compile(r"(?:\b(?:в|к|на)\s+)?(?<![\d.:])([01]?\d|2[0-3]):([0-5]\d)(?![\d:])", re.I)
CLOCK_DOT_RE = re.compile(r"\b(?:в|к|на)\s+([01]?\d|2[0-3])\.([0-5]\d)(?![\d.])", re.I)
DAYWORD_RE = re.compile(r"\b(сегодня|послезавтра|завтра)\b", re.I)
DMY_RE = re.compile(r"(?:\bна\s+)?(?<![\d.:])(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?(?![\d.:])", re.I)
MONTH_RE = re.compile(r"(?:\bна\s+)?\b(\d{1,2})\s+(" + "|".join(MONTHS_GEN) + r")(?:\s+(\d{4}))?\b", re.I)
WEEKDAY_RE = re.compile(r"\bв(?:о)?\s+(" + "|".join(WD_FORMS) + r")\b", re.I)
LEAD_RE = re.compile(r"^\s*(?:напомни(?:ть)?|напоминай)(?:\s+мне)?\b[\s,:—-]*(?:(?:о|об|про|что(?:бы)?)\s+)?", re.I)
HW_RE = re.compile(r"(?<![а-яё])(дз|домашк\w*|домашн\w*)", re.I)


def parse_deadline(text: str) -> tuple[str, Optional[str]]:
    """'задача 5 до 15.10' -> ('задача 5', '2026-10-15')"""
    m = DATE_RE.search(text)
    if not m:
        return text.strip(), None
    d, mo, y = int(m.group(1)), int(m.group(2)), m.group(3)
    year = int(y) + (2000 if y and len(y) == 2 else 0) if y else now().year
    try:
        dl = date(year, mo, d)
    except ValueError:
        return text.strip(), None
    if not y and dl < now().date():
        dl = date(year + 1, mo, d)
    return text[: m.start()].strip(), dl.isoformat()


def parse_when(text: str, base_day: Optional[str] = None) -> dict:
    """-> {"due": datetime|None, "day": date|None, "rest": str, "error": str|None, "used_tomorrow": bool}"""
    t = now()
    buf = [text]
    res = {"due": None, "day": None, "rest": "", "error": None, "used_tomorrow": False}

    def take(rx):
        m = rx.search(buf[0])
        if m:
            a, b = m.span()
            buf[0] = buf[0][:a] + " " * (b - a) + buf[0][b:]
        return m

    rel = take(REL_RE)
    clock = take(CLOCK_COLON_RE) or take(CLOCK_DOT_RE)
    day: Optional[date] = date.fromisoformat(base_day) if base_day else None
    explicit_day = False

    dw = take(DAYWORD_RE)
    if dw:
        word = dw.group(1).lower()
        day = t.date() + timedelta(days={"сегодня": 0, "завтра": 1, "послезавтра": 2}[word])
        explicit_day = True
        res["used_tomorrow"] = word == "завтра"
    else:
        m = take(MONTH_RE)
        if m:
            d, mo, y = int(m.group(1)), MONTHS_GEN.index(m.group(2).lower()) + 1, m.group(3)
        else:
            m = take(DMY_RE)
            if m:
                d, mo, y = int(m.group(1)), int(m.group(2)), m.group(3)
        if m:
            year = (int(y) + (2000 if len(y) == 2 else 0)) if y else t.year
            try:
                day = date(year, mo, d)
            except ValueError:
                res["error"] = "Такой даты нет."
                return res
            if not y and day < t.date():
                day = date(year + 1, mo, d)
            explicit_day = True
        else:
            m = take(WEEKDAY_RE)
            if m:
                wd = WD_FORMS[m.group(1).lower()]
                ahead = (wd - t.weekday()) % 7 or 7
                day = t.date() + timedelta(days=ahead)
                explicit_day = True

    rest = LEAD_RE.sub("", buf[0])
    rest = re.sub(r"\s+", " ", rest).strip(" ,.;:—-")
    rest = re.sub(r"^(?:о|об|про|что(?:бы)?)\s+", "", rest, flags=re.I)
    res["rest"] = rest

    if rel:
        n = int(rel.group(1)) if rel.group(1) else 1
        unit = rel.group(2).lower()
        if unit == "полчаса":
            res["due"] = t + timedelta(minutes=30)
        elif unit.startswith("мин"):
            res["due"] = t + timedelta(minutes=n)
        elif unit.startswith("час") or unit == "ч":
            res["due"] = t + timedelta(hours=n)
        else:
            day = t.date() + timedelta(days=n)
            if clock:
                res["due"] = at(day, f"{int(clock.group(1)):02d}:{clock.group(2)}")
            else:
                res["day"] = day
        if res["due"]:
            res["due"] = res["due"].replace(second=0, microsecond=0)
        return res

    if clock:
        hhmm = f"{int(clock.group(1)):02d}:{clock.group(2)}"
        if day is None:
            day = t.date()
            if at(day, hhmm) <= t:
                day += timedelta(days=1)
        due = at(day, hhmm)
        if due <= t:
            res["error"] = f"{fmt_dt(due)} уже прошло — укажи другое время."
            return res
        res["due"] = due
        return res

    if day is not None:
        res["day"] = day
    return res


def mentions_hw(text: str) -> bool:
    return bool(HW_RE.search(text))

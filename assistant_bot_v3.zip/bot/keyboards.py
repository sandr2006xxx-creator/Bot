"""Инлайн-клавиатуры с пагинацией."""
from math import ceil
from typing import Optional

from aiogram.types import InlineKeyboardButton as Btn, InlineKeyboardMarkup

from .config import MONTHS_GEN, PAGE_SIZE, SNOOZE_MIN


def paginate(buttons: list[Btn], page: int, prefix: str, per_row: int = 2,
             head: Optional[list[list[Btn]]] = None, tail: Optional[list[list[Btn]]] = None) -> InlineKeyboardMarkup:
    pages = max(1, ceil(len(buttons) / PAGE_SIZE))
    page = max(0, min(page, pages - 1))
    chunk = buttons[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]
    rows = list(head or []) + [chunk[i:i + per_row] for i in range(0, len(chunk), per_row)]
    if pages > 1:
        rows.append([
            Btn(text="◀️", callback_data=f"{prefix}:{page - 1}") if page > 0 else Btn(text="·", callback_data="noop"),
            Btn(text=f"{page + 1}/{pages}", callback_data="noop"),
            Btn(text="▶️", callback_data=f"{prefix}:{page + 1}") if page < pages - 1 else Btn(text="·", callback_data="noop"),
        ])
    rows += list(tail or [])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def hw_buttons(items: list[dict], page: int) -> list[Btn]:
    return [Btn(text=f"✅ {h['subject'][:18]}", callback_data=f"done:{h['id']}:{page}") for h in items]


def summary_keyboard(items: list[dict], page: int = 0, route: Optional[str] = None) -> InlineKeyboardMarkup:
    head = [[Btn(text="📍 Маршрут до вуза", url=route)]] if route else None
    return paginate(hw_buttons(items, page), page, "sump", head=head)


def dz_keyboard(items: list[dict], page: int = 0) -> InlineKeyboardMarkup:
    return paginate(hw_buttons(items, page), page, "dzp")


def hw_notify_keyboard(items: list[dict], page: int = 0) -> InlineKeyboardMarkup:
    snooze = [[Btn(text=f"⏰ Отложить на {SNOOZE_MIN} мин", callback_data="hwsnz:30"),
               Btn(text="🌙 Напомнить вечером", callback_data="hwsnz:eve")]]
    return paginate(hw_buttons(items, page), page, "sump", tail=snooze)


def timed_keyboard(rid: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [Btn(text="✅ Выполнено", callback_data=f"tdone:{rid}")],
        [Btn(text=f"⏰ Отложить на {SNOOZE_MIN} мин", callback_data=f"tsnz:{rid}:30"),
         Btn(text="🌙 Напомнить вечером", callback_data=f"tsnz:{rid}:eve")],
    ])


def confirm_keyboard(rid: int, back_to=None) -> InlineKeyboardMarkup:
    rows = []
    if back_to is not None:
        rows.append([Btn(text=f"↩️ Перенести на {back_to.day} {MONTHS_GEN[back_to.month - 1]}",
                         callback_data=f"tback:{rid}")])
    rows.append([Btn(text="❌ Отменить", callback_data=f"tcan:{rid}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def reminders_keyboard(pending: list[dict], unchecked: list[dict], dated: list[dict], page: int = 0) -> InlineKeyboardMarkup:
    buttons = ([Btn(text=f"❌ {r['text'][:28]}", callback_data=f"tcan:{r['id']}") for r in pending]
               + [Btn(text=f"✅ {r['text'][:28]}", callback_data=f"tdone:{r['id']}") for r in unchecked]
               + [Btn(text=f"✅ {r['title'][:28]}", callback_data=f"rdone:{r['id']}") for r in dated])
    return paginate(buttons, page, "remp", per_row=1)


def choice_keyboard(options: list[tuple[str, str]], per_row: int = 2) -> InlineKeyboardMarkup:
    btns = [Btn(text=t, callback_data=d) for t, d in options]
    return InlineKeyboardMarkup(inline_keyboard=[btns[i:i + per_row] for i in range(0, len(btns), per_row)])

"""Загружает профиль пользователя в data["user"]. Заменяет фильтр по OWNER_ID."""
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from .storage import store
from .utils import now


class UserMiddleware(BaseMiddleware):
    async def __call__(self, handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
                       event: TelegramObject, data: dict[str, Any]) -> Any:
        tg = data.get("event_from_user")
        if tg is None or tg.is_bot:
            return None
        user = await store.get_or_create_user(tg.id, tg.full_name, tg.username or "")
        seen = user.get("last_seen")
        stale = not seen or now() - datetime.fromisoformat(seen) > timedelta(hours=1)
        if not user["active"] or stale:
            user = await store.update_user(tg.id, active=True, last_seen=now().isoformat(),
                                           username=tg.username or "")
        data["user"] = user
        return await handler(event, data)

"""Сводки, напоминания, «Мои напоминания», ICS — всё от профиля пользователя (dict из таблицы users)."""
import asyncio
import logging
from datetime import date, datetime, timedelta, timezone
from typing import Optional
from urllib.parse import urlencode

from aiogram import html
from aiogram.types import InlineKeyboardMarkup

from .config import DAYS_RU, REMINDER_HORIZON, SNOOZE_MIN
from .data_sources import (fetch_weather, schedule_from_db, schedule_from_rows, shift_from_db, shift_info,
                           univ_rows, week_name, work_rows)
from .keyboards import hw_notify_keyboard, reminders_keyboard, summary_keyboard, timed_keyboard
from .parsers import mentions_hw
from .runtime import bot
from .storage import store
from .texts import (classes_text, hw_blocks, hw_lines, reminders_text, shift_text, timed_line,
                    timed_upcoming_text, weather_now_text, weather_tomorrow_text)
from .utils import at, fmt_dt, now, sentence, split_message

log = logging.getLogger("bot.services")


async def send_long(chat_id: int, text: str, kb: Optional[InlineKeyboardMarkup] = None) -> None:
    chunks = split_message(text)
    for i, chunk in enumerate(chunks):
        await bot.send_message(chat_id, chunk, reply_markup=kb if i == len(chunks) - 1 else None)


def route_url(u: dict) -> Optional[str]:
    if not u.get("univ_address"):
        return None
    return "https://yandex.ru/maps/?" + urlencode({"mode": "routes", "rtext": f"~{u['univ_address']}", "rtt": "auto"})


# ---------- расписание и смены с учётом режима пользователя ----------
async def schedule_for(u: dict, day: date, urows=None) -> Optional[str]:
    if u["study_mode"] == "sheet":
        rows = urows if urows is not None else await univ_rows(u["univ_sheet_id"])
        return schedule_from_rows(rows, day, u["semester_start"], u["starts_plus"])
    if u["study_mode"] == "manual":
        return schedule_from_db(await store.schedule(u["user_id"], "study"), day, u["semester_start"], u["starts_plus"])
    return ""


async def shift_for(u: dict, day: date, wrows=None) -> tuple[str, Optional[str]]:
    if u["work_mode"] == "sheet":
        rows = wrows if wrows is not None else await work_rows(u["work_sheet_id"])
        return shift_info(rows, day, u["work_surname"])
    if u["work_mode"] == "manual":
        return shift_from_db(await store.schedule(u["user_id"], "work"), day)
    return "none", None


def wn(u: dict, day: date) -> str:
    return week_name(day, u["semester_start"], u["starts_plus"])[1]


async def remember_after_shift(uid: int, info: tuple[str, Optional[str]], day: date) -> None:
    if info[0] != "work":
        return
    due = at(day, info[1]) + timedelta(minutes=30)
    a = await store.uget(uid, "after_shift")
    if a and a.get("due") == due.isoformat():
        return
    await store.uset(uid, "after_shift", {"date": day.isoformat(), "due": due.isoformat(), "sent": False})


# ---------- сводки ----------
async def _extras(uid: int) -> list[str]:
    reminders, pending = await asyncio.gather(store.active_reminders(uid), store.timed(uid, "pending"))
    return [x for x in (reminders_text(reminders, REMINDER_HORIZON), timed_upcoming_text(pending)) if x]


async def _none():
    return None


async def _sources(u: dict):
    return await asyncio.gather(
        fetch_weather(u["lat"], u["lon"]),
        work_rows(u["work_sheet_id"]) if u["work_mode"] == "sheet" else _none(),
        univ_rows(u["univ_sheet_id"]) if u["study_mode"] == "sheet" else _none(),
        store.pending_hw(u["user_id"]))


def _day_block(u: dict, sched, shift, day: date, label_cls: str, label_shift: str) -> str:
    s = classes_text(sched, wn(u, day), label_cls) if u["study_mode"] != "none" else ""
    return s + shift_text(shift, label_shift)


async def build_summary(u: dict, include_tomorrow: bool) -> tuple[str, InlineKeyboardMarkup]:
    uid = u["user_id"]
    today = now().date()
    tomorrow = today + timedelta(days=1)
    weather, w_rows, u_rows, items = await _sources(u)
    shift_today = await shift_for(u, today, w_rows)
    sched_today = await schedule_for(u, today, u_rows)
    await remember_after_shift(uid, shift_today, today)

    hour = now().hour
    greet = "🌅 Доброе утро" if 5 <= hour < 12 else "☀️ Добрый день" if 12 <= hour < 18 else "🌙 Добрый вечер"
    blocks = [f"{greet}, {html.quote(u['name'] or 'друг')}! Сегодня {today.strftime('%d.%m')}, {DAYS_RU[today.weekday()].lower()}"]
    if u["lat"] is not None:
        blocks.append(weather_now_text(weather).rstrip())
    day_block = _day_block(u, sched_today, shift_today, today, "Сегодня", "Сегодня").rstrip()
    if day_block:
        blocks.append(day_block)
    schedules = [(sched_today, "📎 к сегодняшней паре")]

    if include_tomorrow:
        sched_tmr = await schedule_for(u, tomorrow, u_rows)
        tmr = ("<b>Завтра</b>\n" + (weather_tomorrow_text(weather) if u["lat"] is not None else "")
               + _day_block(u, sched_tmr, await shift_for(u, tomorrow, w_rows), tomorrow, "Завтра", "Завтра"))
        if tmr.strip() != "<b>Завтра</b>":
            blocks.append(tmr.rstrip())
        schedules.append((sched_tmr, "📎 к завтрашней паре"))

    blocks += hw_blocks(items, schedules)
    blocks += await _extras(uid)
    if u.get("univ_address"):
        blocks.append(f"📍 Вуз: {html.quote(u['univ_address'])} — маршрут по кнопке ниже")
    return "\n\n".join(blocks), summary_keyboard(items, route=route_url(u))


async def build_evening(u: dict) -> tuple[str, InlineKeyboardMarkup]:
    tomorrow = now().date() + timedelta(days=1)
    weather, w_rows, u_rows, items = await _sources(u)
    sched_tmr = await schedule_for(u, tomorrow, u_rows)
    head = (f"🌙 План на завтра, {tomorrow.strftime('%d.%m')} ({DAYS_RU[tomorrow.weekday()].lower()})\n\n"
            + (weather_tomorrow_text(weather) if u["lat"] is not None else "")
            + _day_block(u, sched_tmr, await shift_for(u, tomorrow, w_rows), tomorrow, "Пары", "Работа"))
    blocks = [head.rstrip()] + hw_blocks(items, [(sched_tmr, "📎 к завтрашней паре")]) + await _extras(u["user_id"])
    return "\n\n".join(blocks), summary_keyboard(items, route=route_url(u))


async def dz_text(items: list[dict]) -> str:
    return ("📚 Домашки:\n" + hw_lines(items)) if items else "Домашек нет — красавчик 🔥"


async def send_hw_reminder(uid: int, title: str) -> None:
    items = await store.pending_hw(uid)
    if items:
        await send_long(uid, f"{title}\n\n" + hw_lines(items), hw_notify_keyboard(items))


# ---------- напоминания на время ----------
async def add_timed(uid: int, text: str, due: datetime, with_hw: Optional[bool] = None) -> dict:
    with_hw = mentions_hw(text) if with_hw is None else with_hw
    return await store.add_timed(uid, sentence(text), due, with_hw)


async def evening_target(uid: int) -> datetime:
    t = now()
    times = await store.times(uid)
    due = at(t.date(), times["evening"])
    return due if due > t + timedelta(minutes=5) else at(t.date() + timedelta(days=1), times["evening"])


def snooze_target_sync(how: str, evening: datetime) -> datetime:
    return (now() + timedelta(minutes=SNOOZE_MIN)).replace(second=0, microsecond=0) if how == "30" else evening


def confirm_text(r: dict) -> str:
    tail = " Вместе с невыполненными ДЗ." if r["with_hw"] else " Вместе со сводкой дня."
    return f"⏰ Напомню {fmt_dt(datetime.fromisoformat(r['due']))}:\n{html.quote(r['text'])}{tail}"


async def fire_timed(u: dict, r: dict) -> None:
    uid = u["user_id"]
    due = datetime.fromisoformat(r["due"])
    late = now() - due
    body = f"🔔 <b>Напоминание</b>\n{html.quote(r['text'])}"
    if late > timedelta(minutes=3):
        body += f"\n<i>Должно было прийти {fmt_dt(due)} — бот был недоступен.</i>"
    if r["with_hw"]:
        items = await store.pending_hw(uid)
        body += "\n\n📚 Невыполненные ДЗ:\n" + (hw_lines(items) if items else "нет — всё сделано 🔥")
    await send_long(uid, body, timed_keyboard(r["id"]))
    await store.update_timed(r["id"], status="sent", sent_at=now().isoformat())
    if r["with_summary"]:
        try:
            text, kb = await build_summary(u, include_tomorrow=True)
            await send_long(uid, text, kb)
        except Exception:
            log.exception("Сводка к напоминанию %s не отправилась", r["id"])


# ---------- «Мои напоминания» ----------
async def my_reminders(uid: int, page: int = 0) -> tuple[str, InlineKeyboardMarkup]:
    pending, unchecked, dated, times = await asyncio.gather(
        store.timed(uid, "pending"), store.timed(uid, "sent"), store.active_reminders(uid), store.times(uid))
    if not (pending or unchecked or dated):
        return ("🗂 Мои напоминания\n\nПока пусто. Примеры:\n<code>Напомни завтра в 08:00 взять документы</code>\n"
                "<code>Напомни через 40 минут сделать ДЗ</code>\n<code>! ОСАГО до 01.03.2027</code>"), \
            InlineKeyboardMarkup(inline_keyboard=[])
    parts = ["🗂 Мои напоминания"]
    if pending:
        parts.append("⏰ Запланировано:\n" + "\n".join(timed_line(r) for r in pending))
    if unchecked:
        parts.append("🔔 Отправлено, не отмечено:\n" + "\n".join(timed_line(r) for r in unchecked))
    if dated:
        parts.append("📌 По датам:\n" + reminders_text(dated, 10_000))
    parts.append(f"Сводка: утром в {times['morning']}, план на завтра в {times['evening']}.")
    return "\n\n".join(parts), reminders_keyboard(pending, unchecked, dated, page)


# ---------- ICS ----------
def _ics_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


async def build_ics(uid: int) -> bytes:
    items, dated, pending = await asyncio.gather(store.pending_hw(uid), store.active_reminders(uid), store.timed(uid, "pending"))
    stamp = now().astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//assistant-bot//RU", "CALSCALE:GREGORIAN",
             "X-WR-CALNAME:Учёба и напоминания"]

    def allday(uid_: str, day: str, title: str, desc: str = "") -> None:
        d = datetime.fromisoformat(day)
        lines.extend(["BEGIN:VEVENT", f"UID:{uid_}@assistant-bot", f"DTSTAMP:{stamp}",
                      f"DTSTART;VALUE=DATE:{d:%Y%m%d}", f"DTEND;VALUE=DATE:{(d + timedelta(days=1)):%Y%m%d}",
                      f"SUMMARY:{_ics_escape(title)}"] + ([f"DESCRIPTION:{_ics_escape(desc)}"] if desc else []) + ["END:VEVENT"])

    for h in items:
        if h["deadline"]:
            allday(f"hw-{h['id']}", h["deadline"], f"ДЗ: {h['subject']}", h["task"])
    for r in dated:
        allday(f"rem-{r['id']}", r["date"], r["title"])
    for r in pending:
        start = datetime.fromisoformat(r["due"]).astimezone(timezone.utc)
        lines.extend(["BEGIN:VEVENT", f"UID:timed-{r['id']}@assistant-bot", f"DTSTAMP:{stamp}",
                      f"DTSTART:{start:%Y%m%dT%H%M%SZ}", f"DTEND:{(start + timedelta(minutes=30)):%Y%m%dT%H%M%SZ}",
                      f"SUMMARY:{_ics_escape(r['text'])}", "END:VEVENT"])
    lines.append("END:VCALENDAR")
    return ("\r\n".join(lines) + "\r\n").encode("utf-8")

"""Мелкие чистые функции: время, форматирование, нарезка сообщений."""
import re
from datetime import date, datetime
from typing import Optional

from .config import MAX_MSG, MONTHS_GEN, TZ

TIME_RE = re.compile(r"(\d{1,2})[:.](\d{2})")


def now() -> datetime:
    return datetime.now(TZ)


def norm(text: Optional[str]) -> str:
    return " ".join((text or "").replace("\ufe0f", "").lower().split())


def at(day: date, hhmm: str) -> datetime:
    h, m = map(int, hhmm.split(":"))
    return datetime(day.year, day.month, day.day, h, m, tzinfo=TZ)


def fmt_dt(dt: datetime) -> str:
    dt = dt.astimezone(TZ)
    year = f" {dt.year}" if dt.year != now().year else ""
    return f"{dt.day} {MONTHS_GEN[dt.month - 1]}{year} в {dt:%H:%M}"


def fmt_day(d: date) -> str:
    year = f" {d.year}" if d.year != now().year else ""
    return f"{d.day} {MONTHS_GEN[d.month - 1]}{year}"


def sentence(text: str) -> str:
    text = text.strip()
    if not text:
        return "Напоминание."
    text = text[0].upper() + text[1:]
    return text if text[-1] in ".!?…" else text + "."


def days_left(iso: str) -> int:
    return (date.fromisoformat(iso) - now().date()).days


def fmt_deadline(iso: Optional[str]) -> str:
    if not iso:
        return ""
    n = days_left(iso)
    d = date.fromisoformat(iso).strftime("%d.%m")
    if n < 0:
        return f" — ⚠️ просрочено ({d})"
    if n == 0:
        return " — 🔥 сегодня!"
    if n == 1:
        return " — 🔥 завтра"
    return f" — до {d} ({n} дн.)"


def split_message(text: str, limit: int = MAX_MSG) -> list[str]:
    """Режем по пустым строкам, затем по строкам — HTML-теги не разрываются."""
    chunks, cur = [], ""
    for block in text.split("\n\n"):
        parts = [block] if len(block) <= limit else block.split("\n")
        for part in parts:
            sep = "\n\n" if part is block else "\n"
            if cur and len(cur) + len(sep) + len(part) > limit:
                chunks.append(cur)
                cur = ""
            cur = f"{cur}{sep}{part}" if cur else part
    if cur:
        chunks.append(cur)
    return chunks or ["—"]

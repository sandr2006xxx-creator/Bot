"""Чистые функции формирования текста. Ничего не читают из базы — всё приходит аргументами."""
import re
from datetime import date, datetime, timedelta
from typing import Optional

from aiogram import html

from .config import COLD_THRESHOLD
from .utils import days_left, fmt_deadline, fmt_dt, now

try:
    from rapidfuzz import fuzz
except ImportError:          # без rapidfuzz работаем на простом вхождении
    fuzz = None


def weather_now_text(w: Optional[dict]) -> str:
    if not w or "current" not in w:
        return "🌡 Погода недоступна.\n"
    c = w["current"]
    t, feels = c["temperature_2m"], c["apparent_temperature"]
    line = f"🌡 За окном <b>{t:+.0f}°C</b>, ощущается {feels:+.0f}°C"
    if c.get("precipitation", 0) > 0:
        line += ", 🌧 осадки"
    if c.get("wind_speed_10m", 0) >= 8:
        line += f", 💨 ветер {c['wind_speed_10m']:.0f} м/с"
    line += "\n"
    line += ("❄️ Холодно — заложи +10 мин на прогрев машины.\n" if feels < COLD_THRESHOLD
             else "🚗 Тепло, долгий прогрев не нужен.\n")
    return line


def weather_tomorrow_text(w: Optional[dict]) -> str:
    if not w or "daily" not in w:
        return ""
    d = w["daily"]
    try:
        tmin, tmax = d["temperature_2m_min"][1], d["temperature_2m_max"][1]
        snow, rain = d["snowfall_sum"][1] or 0, d["precipitation_sum"][1] or 0
    except (IndexError, KeyError):
        return ""
    line = f"🌡 Завтра {tmin:+.0f}…{tmax:+.0f}°C"
    if snow > 0.5:
        line += f", 🌨 снег ~{snow:.0f} см — выйди на 15 мин раньше, чистить машину"
    elif rain > 1 and tmin < 1:
        line += ", 🧊 осадки при минусе — возможен гололёд, аккуратнее"
    elif rain > 1:
        line += ", 🌧 дождь"
    if tmin < COLD_THRESHOLD and snow <= 0.5:
        line += " — утром греть машину"
    return line + "\n"


def classes_text(schedule: Optional[str], wn: str, label: str) -> str:
    tag = f" ({wn})" if wn else ""
    if schedule is None:
        return f"🎓 {label}{tag}: ⚠️ расписание недоступно\n"
    if not schedule:
        return f"🎓 {label}{tag}: 🎉 пар нет\n"
    return f"🎓 {label}{tag}:\n{html.quote(schedule)}\n"


def shift_text(info: tuple[str, Optional[str]], label: str) -> str:
    kind, value = info
    if kind == "none":
        return ""
    if kind == "work":
        return f"💼 {label}: смена до <b>{value}</b>\n"
    if kind == "off":
        return f"🌴 {label}: выходной от работы\n"
    if kind == "other":
        return f"💼 {label}: в графике «{html.quote(value)}»\n"
    return f"⚠️ {label}: не удалось проверить смену ({html.quote(value)})\n"


def hw_lines(items: list[dict], notes: Optional[dict[int, str]] = None) -> str:
    notes = notes or {}
    return "\n".join(
        f"• <b>{html.quote(h['subject'])}</b>: {html.quote(h['task'])}{fmt_deadline(h['deadline'])}"
        + (f" · {notes[h['id']]}" if h["id"] in notes else "")
        for h in items)


SUBJECT_ALIASES = {   # студенческие сокращения → как предмет записан в расписании
    "матан": ["математический анализ", "мат. анализ", "мат анализ"],
    "линал": ["линейная алгебра"],
    "аналит": ["аналитическая геометрия"],
    "дискретка": ["дискретная математика"],
    "теорвер": ["теория вероятностей"],
    "физра": ["физическая культура", "физкультура"],
    "англ": ["английский", "иностранный язык"],
    "инфа": ["информатика"],
    "бжд": ["безопасность жизнедеятельности"],
    "прога": ["программирование"],
    "философия": ["философия"],
}


def subject_in_schedule(subject: str, schedule: str) -> bool:
    """Точное вхождение, алиасы, префиксы слов, затем нечёткое сравнение (rapidfuzz)."""
    subj, s = subject.lower().strip(), schedule.lower()
    if not subj:
        return False
    if subj in s or any(a in s for a in SUBJECT_ALIASES.get(subj, [])):
        return True
    words = [w for w in re.findall(r"\w+", subj) if len(w) >= 4]
    if any(w[:5] in s for w in words):
        return True
    if fuzz is None:
        return False
    if fuzz.partial_ratio(subj, s) >= 88:
        return True
    tokens = [t for t in re.findall(r"\w+", s) if len(t) >= 4]
    return any(fuzz.ratio(subj, t) >= 80 for t in tokens)


def hw_for_schedule(items: list[dict], schedule: Optional[str]) -> list[dict]:
    if not schedule:
        return []
    return [h for h in items if subject_in_schedule(h["subject"], schedule)]


def hw_blocks(items: list[dict], schedules: list[tuple[Optional[str], str]]) -> list[str]:
    """Сначала срочное, затем остальное. Каждое ДЗ — ровно один раз."""
    if not items:
        return ["📚 Домашек нет — красавчик 🔥"]
    notes: dict[int, str] = {}
    for sched, note in schedules:
        for h in hw_for_schedule(items, sched):
            notes.setdefault(h["id"], note)
    urgent = [h for h in items if h["id"] in notes or (h["deadline"] and days_left(h["deadline"]) <= 1)]
    rest = [h for h in items if h not in urgent]
    blocks = []
    if urgent:
        blocks.append("🔥 <b>Срочно</b>:\n" + hw_lines(urgent, notes))
    if rest:
        blocks.append(("📚 Остальные домашки:\n" if urgent else "📚 Домашки:\n") + hw_lines(rest))
    return blocks


def reminders_text(reminders: list[dict], horizon: int) -> str:
    soon = [r for r in reminders if days_left(r["date"]) <= horizon]
    if not soon:
        return ""
    lines = []
    for r in sorted(soon, key=lambda r: r["date"]):
        n = days_left(r["date"])
        d = date.fromisoformat(r["date"]).strftime("%d.%m")
        when = (f"⚠️ просрочено на {-n} дн." if n < 0 else "сегодня" if n == 0
                else "завтра" if n == 1 else f"через {n} дн.")
        lines.append(f"📌 {html.quote(r['title'])} — {when} ({d})")
    return "\n".join(lines)


def timed_upcoming_text(pending: list[dict], hours: int = 36) -> str:
    t = now()
    soon = [r for r in pending if datetime.fromisoformat(r["due"]) - t <= timedelta(hours=hours)]
    if not soon:
        return ""
    return "⏰ Скоро напомню:\n" + "\n".join(
        f"• {fmt_dt(datetime.fromisoformat(r['due']))} — {html.quote(r['text'])}" for r in soon)


def timed_line(r: dict) -> str:
    return f"• {fmt_dt(datetime.fromisoformat(r['due']))} — {html.quote(r['text'])}"

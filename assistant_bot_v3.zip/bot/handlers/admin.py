"""Команды администратора (OWNER_ID): /admin, /broadcast."""
from aiogram import F, Router, html
from aiogram.filters import Command
from aiogram.types import Message

from ..config import OWNER_ID
from ..data_sources import http
from ..runtime import bot
from ..storage import store
from ..utils import now

router = Router(name="admin")
router.message.filter(F.from_user.id == OWNER_ID)


@router.message(Command("admin"))
async def admin_cmd(message: Message):
    st, c = await store.admin_stats(), await store.counts()
    fails = "\n".join(f"• {k[:70]}: {v}" for k, v in sorted(http.fails.items(), key=lambda x: -x[1])[:5]) or "нет"
    await message.answer(
        f"🛠 Админ · {now():%d.%m %H:%M}\n"
        f"Пользователей: {st['users']}, активных: {st['active']}, новых за 7 дн: {st['new_week']}\n"
        f"ДЗ открыто: {c['hw']}, напоминаний: {c['rem']} + {c['timed_pending']} по времени\n"
        f"URL в кэше: {len(http.cache)}\nСбои источников:\n{html.quote(fails)}")


@router.message(Command("broadcast"))
async def broadcast_cmd(message: Message):
    parts = (message.text or "").split(maxsplit=1)
    text = parts[1].strip() if len(parts) > 1 else ""
    if not text:
        await message.answer("Использование: /broadcast текст")
        return
    ok = fail = 0
    for u in await store.active_users():
        try:
            await bot.send_message(u["user_id"], f"📣 {html.quote(text)}")
            ok += 1
        except Exception:
            fail += 1
    await message.answer(f"Отправлено: {ok}, ошибок: {fail}")

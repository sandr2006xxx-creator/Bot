"""Добавление домашки: «+ Предмет - Задание до 15.10» и напоминания на дату: «! ОСАГО до 01.03.2027»."""
import re
from datetime import date

from aiogram import F, Router, html
from aiogram.types import Message

from ..config import MAX_HW_PER_USER
from ..parsers import parse_deadline
from ..storage import store
from ..texts import hw_lines

router = Router(name="homework")


@router.message(F.text.regexp(r"^\+\s*\S"))
async def add_hw(message: Message, user: dict):
    uid = user["user_id"]
    body, deadline = parse_deadline(message.text[1:].strip())
    parts = re.split(r"\s*[-—:]\s*", body, maxsplit=1)
    if len(parts) != 2 or not all(parts):
        await message.answer("Формат: <code>+ Предмет - Задание до 15.10</code>")
        return
    if len(await store.pending_hw(uid)) >= MAX_HW_PER_USER:
        await message.answer("Слишком много открытых домашек — закрой часть через /dz.")
        return
    hw = await store.add_hw(uid, parts[0].strip(), parts[1].strip(), deadline)
    await message.answer("✅ Записал:\n" + hw_lines([hw]))


@router.message(F.text.regexp(r"^!\s*\S"))
async def add_reminder(message: Message, user: dict):
    title, when = parse_deadline(message.text[1:].strip())
    if not when:
        await message.answer("Формат: <code>! ОСАГО до 01.03.2027</code>")
        return
    await store.add_reminder(user["user_id"], title, when)
    await message.answer(f"📌 Напомню: {html.quote(title)} — {date.fromisoformat(when).strftime('%d.%m.%Y')}\n"
                         "Буду показывать в сводке, пока не нажмёшь «✅».")

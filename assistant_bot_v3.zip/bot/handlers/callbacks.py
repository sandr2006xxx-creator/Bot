"""Инлайн-кнопки: выполнено / отменить / отложить / пагинация. Каждая запись проверяется на принадлежность пользователю."""
from datetime import datetime, timedelta

from aiogram import F, Router, html
from aiogram.types import CallbackQuery

from ..keyboards import confirm_keyboard, dz_keyboard, hw_notify_keyboard, summary_keyboard
from ..services import add_timed, confirm_text, dz_text, evening_target, my_reminders, route_url, snooze_target_sync
from ..storage import store
from ..utils import fmt_dt, now, split_message

router = Router(name="callbacks")


async def _edit(call: CallbackQuery, text: str = None, kb=None) -> None:
    try:
        if text is None:
            await call.message.edit_reply_markup(reply_markup=kb)
        else:
            await call.message.edit_text(split_message(text)[0], reply_markup=kb)
    except Exception:
        pass


async def refresh_or_strip(call: CallbackQuery, uid: int) -> None:
    if (call.message.text or "").startswith("🗂"):
        text, kb = await my_reminders(uid)
        await _edit(call, text, kb)
    else:
        await _edit(call, None, None)


def _is_dz(call: CallbackQuery) -> bool:
    return (call.message.text or "").startswith("📚 Домашки")


def _is_hw_notify(call: CallbackQuery) -> bool:
    return (call.message.text or "").startswith("🔔 Смена закончилась")


@router.callback_query(F.data == "noop")
async def noop_cb(call: CallbackQuery):
    await call.answer()


@router.callback_query(F.data.startswith("done:"))
async def done_cb(call: CallbackQuery, user: dict):
    uid = user["user_id"]
    _, hw_id, *rest = call.data.split(":")
    page = int(rest[0]) if rest else 0
    await store.hw_done(uid, int(hw_id))
    items = await store.pending_hw(uid)
    if _is_dz(call):
        await _edit(call, await dz_text(items), dz_keyboard(items, page) if items else None)
    elif _is_hw_notify(call):
        await _edit(call, None, hw_notify_keyboard(items, page))
    else:
        await _edit(call, None, summary_keyboard(items, page, route=route_url(user)))
    await call.answer("Готово ✅")


@router.callback_query(F.data.startswith("dzp:"))
async def dz_page_cb(call: CallbackQuery, user: dict):
    items = await store.pending_hw(user["user_id"])
    await _edit(call, None, dz_keyboard(items, int(call.data.split(":")[1])))
    await call.answer()


@router.callback_query(F.data.startswith("sump:"))
async def summary_page_cb(call: CallbackQuery, user: dict):
    items = await store.pending_hw(user["user_id"])
    page = int(call.data.split(":")[1])
    await _edit(call, None, hw_notify_keyboard(items, page) if _is_hw_notify(call)
                else summary_keyboard(items, page, route=route_url(user)))
    await call.answer()


@router.callback_query(F.data.startswith("remp:"))
async def rem_page_cb(call: CallbackQuery, user: dict):
    text, kb = await my_reminders(user["user_id"], int(call.data.split(":")[1]))
    await _edit(call, text, kb)
    await call.answer()


@router.callback_query(F.data.startswith("rdone:"))
async def rdone_cb(call: CallbackQuery, user: dict):
    await store.reminder_done(user["user_id"], int(call.data.split(":", 1)[1]))
    await refresh_or_strip(call, user["user_id"])
    await call.answer("Готово ✅")


@router.callback_query(F.data.startswith("tdone:"))
async def tdone_cb(call: CallbackQuery, user: dict):
    uid = user["user_id"]
    r = await store.find_timed(uid, int(call.data.split(":", 1)[1]))
    if r:
        await store.update_timed(r["id"], status="done")
    if (call.message.text or "").startswith("🔔"):
        await _edit(call, f"✅ {html.quote(r['text'])}" if r else "✅ Выполнено", None)
    else:
        await refresh_or_strip(call, uid)
    await call.answer("Выполнено ✅")


@router.callback_query(F.data.startswith("tcan:"))
async def tcan_cb(call: CallbackQuery, user: dict):
    uid = user["user_id"]
    r = await store.find_timed(uid, int(call.data.split(":", 1)[1]))
    if r and r["status"] == "pending":
        await store.update_timed(r["id"], status="cancelled")
        if (call.message.text or "").startswith("🗂"):
            await refresh_or_strip(call, uid)
        else:
            await _edit(call, f"❌ Отменено: {html.quote(r['text'])}", None)
        await call.answer("Отменено")
    else:
        await call.answer("Уже неактуально")


@router.callback_query(F.data.startswith("tback:"))
async def tback_cb(call: CallbackQuery, user: dict):
    r = await store.find_timed(user["user_id"], int(call.data.split(":", 1)[1]))
    if not r or r["status"] != "pending":
        await call.answer("Уже неактуально")
        return
    new_due = datetime.fromisoformat(r["due"]) - timedelta(days=1)
    if new_due <= now():
        await call.answer("Это время уже прошло", show_alert=True)
        return
    await store.update_timed(r["id"], due=new_due.isoformat())
    r["due"] = new_due.isoformat()
    await _edit(call, confirm_text(r), confirm_keyboard(r["id"]))
    await call.answer(f"Перенёс на {fmt_dt(new_due)}")


@router.callback_query(F.data.startswith("tsnz:"))
async def tsnz_cb(call: CallbackQuery, user: dict):
    uid = user["user_id"]
    _, rid, how = call.data.split(":")
    r = await store.find_timed(uid, int(rid))
    if not r:
        await call.answer("Не нашёл напоминание")
        return
    due = snooze_target_sync(how, await evening_target(uid))
    await store.update_timed(r["id"], due=due.isoformat(), status="pending", tries=0)
    if (call.message.text or "").startswith("🗂"):
        await refresh_or_strip(call, uid)
    else:
        await _edit(call, f"⏰ Отложено до {fmt_dt(due)}: {html.quote(r['text'])}", None)
    await call.answer(f"Напомню {fmt_dt(due)}")


@router.callback_query(F.data.startswith("hwsnz:"))
async def hwsnz_cb(call: CallbackQuery, user: dict):
    uid = user["user_id"]
    how = call.data.split(":", 1)[1]
    due = snooze_target_sync(how, await evening_target(uid))
    await add_timed(uid, "Домашки", due, with_hw=True)
    await _edit(call, (call.message.html_text or "") + f"\n\n⏰ Напомню {fmt_dt(due)}", None)
    await call.answer(f"Напомню {fmt_dt(due)}")

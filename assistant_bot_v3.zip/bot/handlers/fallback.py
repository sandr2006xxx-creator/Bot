"""Последний роутер: ответ на ожидание времени и всё остальное."""
from aiogram import F, Router
from aiogram.types import Message

from ..runtime import MENU
from ..storage import store
from .reminders import handle_awaiting

router = Router(name="fallback")


@router.message(F.text)
async def other_text(message: Message, user: dict):
    aw = await store.uget(user["user_id"], "awaiting")
    if aw:
        await handle_awaiting(message, user["user_id"], aw)
        return
    if not user["onboarded"]:
        await message.answer("Сначала настроимся — нажми /start")
        return
    await message.answer("Жми ⭐ Важное или смотри /help", reply_markup=MENU)


@router.message()
async def other(message: Message, user: dict):
    await message.answer("Я понимаю только текст 🙂", reply_markup=MENU)

"""Команды и кнопки меню: /help /id /dz /rem /settings /ics, сводка, отмена, время сводок. (/start — в onboarding.)"""
import re

from aiogram import F, Router, html
from aiogram.filters import Command
from aiogram.types import BufferedInputFile, Message

from ..config import CATCHUP, COLD_THRESHOLD, REMINDER_HORIZON, SNOOZE_MIN
from ..data_sources import csv_url, http
from ..keyboards import dz_keyboard
from ..runtime import BTN_MY, MENU
from ..services import build_ics, build_summary, dz_text, my_reminders, send_long
from ..storage import store
from ..utils import at, norm, now

router = Router(name="commands")

SUMMARY_WORDS = {"⭐ важное", "важное", "напоминание", "напомни", "сводка"}
MY_WORDS = {norm(BTN_MY), "мои напоминания", "напоминания", "список напоминаний"}
CANCEL_WORDS = {"отмена", "отменить", "стоп"}


def help_text(u: dict) -> str:
    return (
        "⭐ <b>Важное</b> или слово «напоминание» / «сводка» — полная сводка: погода, пары, смена, "
        "домашки, сроки, маршрут.\n\n"
        "Добавить домашку:\n<code>+ Матан - задачи 5-7 до 15.10</code>\n(срок «до …» необязателен)\n\n"
        "Напоминание на дату:\n<code>! ОСАГО до 01.03.2027</code>\n\n"
        "Напоминание на время:\n<code>Напомни завтра в 08:00 взять документы</code>\n"
        "<code>Напомни через 40 минут сделать ДЗ</code>\n"
        "Если время не указано — спрошу. «отмена» — отменить ввод.\n\n"
        "Время сводок:\n<code>Присылай сводку каждый день в 07:30</code>\n"
        "<code>Присылай план на завтра в 21:00</code>\n\n"
        "🔔 <b>Мои напоминания</b> — список с отменой и «выполнено».\n"
        "/dz — домашки, /rem — напоминания, /schedule — расписание (ручной режим), /setup — перенастроить, "
        "/settings — настройки, /ics — календарь\n\n"
        f"Сам пишу в {u['morning']} (утро), {u['evening']} (план на завтра) и через 30 мин после смены."
    )


@router.message(Command("help"))
async def help_cmd(message: Message, user: dict):
    await message.answer(help_text(user), reply_markup=MENU)


@router.message(Command("id"))
async def id_cmd(message: Message):
    await message.answer(f"Твой ID: <code>{message.from_user.id}</code>")


@router.message(lambda m: norm(m.text) in SUMMARY_WORDS)
async def important_btn(message: Message, user: dict):
    text, kb = await build_summary(user, include_tomorrow=True)
    await send_long(message.chat.id, text, kb)


@router.message(Command("rem"))
@router.message(lambda m: norm(m.text) in MY_WORDS)
async def rem_cmd(message: Message, user: dict):
    text, kb = await my_reminders(user["user_id"])
    await send_long(message.chat.id, text, kb)


@router.message(Command("dz"))
async def dz_cmd(message: Message, user: dict):
    items = await store.pending_hw(user["user_id"])
    if not items:
        await message.answer("Домашек нет — отдыхай 🔥")
        return
    await send_long(message.chat.id, await dz_text(items), dz_keyboard(items))


def _age(key: str) -> str:
    age = http.cache_age(key)
    return "нет" if age is None else f"{age // 60} мин назад"


@router.message(Command("settings"))
async def settings_cmd(message: Message, user: dict):
    u = user
    c = await store.counts(u["user_id"])
    src = []
    if u["study_mode"] == "sheet":
        src.append(f"• учёба: Google-таблица, обновлено {_age(csv_url(u['univ_sheet_id']))}")
    elif u["study_mode"] == "manual":
        src.append("• учёба: ручной ввод (/schedule)")
    else:
        src.append("• учёба: не настроена")
    if u["work_mode"] == "sheet":
        src.append(f"• работа: Google-таблица, фамилия «{html.quote(u['work_surname'] or '')}», "
                   f"обновлено {_age(csv_url(u['work_sheet_id']))}")
    elif u["work_mode"] == "manual":
        src.append("• работа: ручной ввод (/schedule)")
    else:
        src.append("• работа: нет")
    sem = (f"{u['semester_start'][8:]}.{u['semester_start'][5:7]}.{u['semester_start'][:4]}, первая неделя "
           f"{'➕' if u['starts_plus'] else '➖'}") if u["semester_start"] else "не задан"
    text = (
        f"⚙️ <b>Настройки</b> · {html.quote(u['name'])}\n\n"
        f"🌅 Утренняя сводка: <b>{u['morning']}</b>\n🌙 План на завтра: <b>{u['evening']}</b>\n"
        f"❄️ Порог холода: <b>{COLD_THRESHOLD:+d}°C</b>; 📌 горизонт напоминаний: <b>{REMINDER_HORIZON} дн.</b>; "
        f"⏰ отложить: <b>{SNOOZE_MIN} мин</b>\n\n"
        "🗃 <b>Источники</b>\n" + "\n".join(src) + "\n"
        f"• семестр: {sem}\n"
        f"• город: {html.quote(u['city'] or 'не задан')}; адрес вуза: {html.quote(u['univ_address'] or 'не задан')}\n\n"
        "🗄 <b>Мои данные</b>\n"
        f"• ДЗ открыто/закрыто: {c['hw']}/{c['hw_done']}; напоминаний по дате: {c['rem']}; "
        f"по времени: {c['timed_pending']} в очереди, {c['timed_sent']} ждут «✅»\n\n"
        "Перенастроить — /setup. Время сводок — фразой «Присылай сводку каждый день в 07:30»."
    )
    await message.answer(text)


@router.message(Command("ics"))
async def ics_cmd(message: Message, user: dict):
    data = await build_ics(user["user_id"])
    await message.answer_document(
        BufferedInputFile(data, filename=f"assistant-{now():%Y%m%d}.ics"),
        caption="📅 Календарь: дедлайны ДЗ, напоминания на дату и по времени. Открой файл — он импортируется в "
                "Google/Apple Calendar.")


@router.message(lambda m: norm(m.text) in CANCEL_WORDS)
async def cancel_input(message: Message, user: dict):
    had = await store.uget(user["user_id"], "awaiting")
    await store.uset(user["user_id"], "awaiting", None)
    await message.answer("Ок, отменил ввод напоминания." if had else "Нечего отменять 🙂", reply_markup=MENU)


@router.message(F.text.regexp(r"(?i)^\s*присылай\s+(?:вечерн\w*\s+сводку|план\s+на\s+завтра)\D*?(\d{1,2})[:.](\d{2})"))
@router.message(F.text.regexp(r"(?i)^\s*присылай\s+(?:утренн\w*\s+)?сводку\D*?(\d{1,2})[:.](\d{2})"))
async def set_daily_time(message: Message, user: dict):
    uid = user["user_id"]
    evening = bool(re.match(r"(?i)^\s*присылай\s+(?:вечерн|план)", message.text))
    m = re.search(r"(\d{1,2})[:.](\d{2})", message.text)
    h, mi = int(m.group(1)), int(m.group(2))
    if h > 23 or mi > 59:
        await message.answer("Не понял время. Пример: <code>Присылай сводку каждый день в 07:30</code>")
        return
    kind = "evening" if evening else "morning"
    hhmm = f"{h:02d}:{mi:02d}"
    await store.set_time(uid, kind, hhmm)
    sent = await store.uget(uid, "sent", {})
    name = "План на завтра" if evening else "Сводку"
    t = now()
    if sent.get(kind) == t.date().isoformat():
        start = "Сегодня уже отправлял — по новому времени начну с завтра."
    elif at(t.date(), hhmm) > t:
        start = "Первый раз — сегодня."
    elif t - at(t.date(), hhmm) <= CATCHUP:
        start = "Сегодняшнюю пришлю сейчас."
    else:
        start = "Начну с завтра."
    await message.answer(f"Готово: {name.lower()} присылаю каждый день в {hhmm} по Москве.\n{start}")

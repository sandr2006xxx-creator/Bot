"""Ручной ввод расписания (режим manual). Хранится в таблице schedule для каждого пользователя."""
import re
from datetime import date

from aiogram import F, Router, html
from aiogram.filters import Command
from aiogram.types import Message

from ..config import DAYS_RU, DAYS_SHORT
from ..storage import store
from ..utils import TIME_RE, now

router = Router(name="schedule")

STUDY_RE = re.compile(r"(?i)^\s*(пн|вт|ср|чт|пт|сб|вс)\s*([+\-−]?)\s*[:\-]?\s*(.+)$", re.S)
WORK_RE = re.compile(r"(?i)^\s*(смена|выходной)\s+(\d{1,2})[.](\d{1,2})(?:[.](\d{4}))?\s*(.*)$")


def manual_study(message: Message, user: dict) -> bool:
    return user["study_mode"] == "manual"


def manual_work(message: Message, user: dict) -> bool:
    return user["work_mode"] == "manual"


def _parse_items(body: str) -> list[tuple[str | None, str]]:
    out = []
    for part in re.split(r"[;\n]+", body):
        part = part.strip()
        if not part:
            continue
        m = TIME_RE.match(part)
        start = f"{int(m.group(1)):02d}:{m.group(2)}" if m else None
        text = part[m.end():].strip(" -–—") if m else part
        if text:
            out.append((start, text))
    return out


@router.message(Command("schedule"))
async def schedule_cmd(message: Message, user: dict):
    uid = user["user_id"]
    study, work = await store.schedule(uid, "study"), await store.schedule(uid, "work")
    lines = ["📅 Моё расписание"]
    if user["study_mode"] == "manual":
        if study:
            for wd in range(7):
                items = [e for e in study if e["weekday"] == wd]
                if items:
                    lines.append(f"\n<b>{DAYS_RU[wd]}</b>")
                    for e in items:
                        par = {"plus": " ➕", "minus": " ➖"}.get(e["parity"], "")
                        lines.append(f"• {(e['start'] + ' ') if e['start'] else ''}{html.quote(e['text'])}{par}")
        else:
            lines.append("Пар пока нет.")
        lines.append("\nДобавить: <code>пн+ 09:00 Матан; 10:40 Физика</code>\n"
                     "(+ или − после дня — чётность недели, без знака — каждую неделю)\n"
                     "Очистить день: <code>/clear пн</code>, всё: <code>/clear учёба</code>")
    if user["work_mode"] == "manual":
        today = now().date().isoformat()
        future = [e for e in work if e["date"] and e["date"] >= today]
        lines.append("\n<b>Смены</b>")
        lines.append("\n".join(f"• {e['date'][8:]}.{e['date'][5:7]} — {html.quote(e['text'])}" for e in future[:20])
                     if future else "Смен не записано.")
        lines.append("Добавить: <code>смена 15.10 до 18:00</code>, <code>выходной 16.10</code>. Очистить: <code>/clear работа</code>")
    if user["study_mode"] != "manual" and user["work_mode"] != "manual":
        lines.append("У тебя расписание из Google-таблиц. Переключить на ручной ввод — /setup.")
    await message.answer("\n".join(lines))


@router.message(Command("clear"))
async def clear_cmd(message: Message, user: dict):
    parts = (message.text or "").split(maxsplit=1)
    arg = parts[1].strip().lower() if len(parts) > 1 else ""
    uid = user["user_id"]
    if arg in DAYS_SHORT:
        await store.clear_schedule(uid, "study", DAYS_SHORT.index(arg))
        await message.answer(f"Очистил {DAYS_RU[DAYS_SHORT.index(arg)].lower()}.")
    elif arg.startswith("уч"):
        await store.clear_schedule(uid, "study")
        await message.answer("Очистил расписание учёбы.")
    elif arg.startswith("раб"):
        await store.clear_schedule(uid, "work")
        await message.answer("Очистил смены.")
    else:
        await message.answer("Что очистить? <code>/clear пн</code>, <code>/clear учёба</code>, <code>/clear работа</code>")


@router.message(F.text.regexp(STUDY_RE), manual_study)
async def add_study(message: Message, user: dict):
    m = STUDY_RE.match(message.text)
    wd = DAYS_SHORT.index(m.group(1).lower())
    parity = {"+": "plus", "-": "minus", "−": "minus"}.get(m.group(2)) if m.group(2) else None
    items = _parse_items(m.group(3))
    if not items:
        await message.answer("Не понял пары. Пример: <code>пн+ 09:00 Матан; 10:40 Физика</code>")
        return
    for start, text in items:
        await store.add_schedule(user["user_id"], "study", text[:120], weekday=wd, parity=parity, start=start)
    par = {"plus": " (неделя ➕)", "minus": " (неделя ➖)"}.get(parity, "")
    await message.answer(f"✅ {DAYS_RU[wd]}{par}: добавил {len(items)} пар(ы). Смотреть — /schedule")


@router.message(F.text.regexp(WORK_RE), manual_work)
async def add_work(message: Message, user: dict):
    m = WORK_RE.match(message.text)
    try:
        d = date(int(m.group(4) or now().year), int(m.group(3)), int(m.group(2)))
    except ValueError:
        await message.answer("Не понял дату. Пример: <code>смена 15.10 до 18:00</code>")
        return
    uid = user["user_id"]
    await store.execute("DELETE FROM schedule WHERE user_id=? AND kind='work' AND date=?", (uid, d.isoformat()))
    if m.group(1).lower() == "выходной":
        await store.add_schedule(uid, "work", "выходной", date=d.isoformat())
        await message.answer(f"🌴 {d:%d.%m} — выходной.")
        return
    times = TIME_RE.findall(m.group(5))
    end = f"{int(times[-1][0]):02d}:{times[-1][1]}" if times else None
    await store.add_schedule(uid, "work", m.group(5).strip() or "смена", date=d.isoformat(), end=end)
    await message.answer(f"💼 {d:%d.%m} — смена" + (f" до {end}" if end else "") + ".")

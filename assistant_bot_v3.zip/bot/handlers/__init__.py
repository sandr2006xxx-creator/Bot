"""Корневой роутер: outer-middleware профиля (user доступен уже в фильтрах) + порядок обработчиков."""
from aiogram import Router

from ..middleware import UserMiddleware
from . import admin, callbacks, commands, fallback, homework, onboarding, reminders, schedule

router = Router(name="root")
router.message.outer_middleware(UserMiddleware())
router.callback_query.outer_middleware(UserMiddleware())
router.include_routers(onboarding.router, admin.router, commands.router, schedule.router,
                       homework.router, reminders.router, callbacks.router, fallback.router)

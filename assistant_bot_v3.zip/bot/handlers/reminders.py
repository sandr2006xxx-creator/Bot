"""«Напомни …» — напоминания на время. Ожидание времени хранится per-user (kv awaiting:<uid>)."""
from datetime import date, datetime, timedelta
from typing import Optional

from aiogram import F, Router, html
from aiogram.types import Message

from ..config import MAX_TIMED_PER_USER
from ..keyboards import confirm_keyboard
from ..parsers import parse_when
from ..services import add_timed, confirm_text
from ..storage import store
from ..utils import fmt_day, now, sentence

router = Router(name="reminders")


async def save_and_confirm(message: Message, uid: int, text: str, due: datetime, used_tomorrow: bool) -> None:
    if len(await store.timed(uid, "pending")) >= MAX_TIMED_PER_USER:
        await message.answer("Слишком много запланированных напоминаний — отмени часть через /rem.")
        return
    r = await add_timed(uid, text, due)
    back = datetime.fromisoformat(r["due"]) - timedelta(days=1)
    offer = back if used_tomorrow and now().hour < 5 and back > now() else None
    await message.answer(confirm_text(r), reply_markup=confirm_keyboard(r["id"], offer))


async def ask_time(message: Message, uid: int, text: str, day: Optional[date]) -> None:
    await store.uset(uid, "awaiting", {"text": text, "day": day.isoformat() if day else None})
    when = f" {fmt_day(day)}" if day else ""
    await message.answer(f"Во сколько{when} напомнить «{html.quote(sentence(text))}»? Например <code>в 18:30</code>, "
                         "<code>завтра в 08:00</code>, <code>через 40 минут</code>. Или «отмена».")


@router.message(F.text.regexp(r"(?i)^\s*(?:напомни(?:ть)?|напоминай)\b"))
async def remind_cmd(message: Message, user: dict):
    p = parse_when(message.text)
    if p["error"]:
        await message.answer(p["error"])
        return
    if p["due"]:
        await save_and_confirm(message, user["user_id"], p["rest"], p["due"], p["used_tomorrow"])
        return
    await ask_time(message, user["user_id"], p["rest"], p["day"])


async def handle_awaiting(message: Message, uid: int, aw: dict) -> None:
    p = parse_when(message.text, base_day=aw.get("day"))
    if p["error"]:
        await message.answer(p["error"])
        return
    if p["due"]:
        await store.uset(uid, "awaiting", None)
        await save_and_confirm(message, uid, aw["text"], p["due"], p["used_tomorrow"])
        return
    if p["day"] and p["day"].isoformat() != aw.get("day"):
        await ask_time(message, uid, aw["text"], p["day"])
        return
    await message.answer("Не понял время. Напиши, например, <code>в 18:30</code> или <code>через 40 минут</code>. Или «отмена».")

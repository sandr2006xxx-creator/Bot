"""/start для нового пользователя: пошаговая настройка через FSM. Повторно — /setup."""
import re
from datetime import date

from aiogram import F, Router, html
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from ..config import TEMPLATE_UNIV_SHEET_URL, TEMPLATE_WORK_SHEET_URL
from ..data_sources import geocode, parse_sheet_id, probe_sheet
from ..keyboards import choice_keyboard
from ..runtime import MENU
from ..storage import store

router = Router(name="onboarding")


class Setup(StatesGroup):
    name = State()
    study = State()
    univ_sheet = State()
    semester = State()
    parity = State()
    work = State()
    work_sheet = State()
    surname = State()
    city = State()
    address = State()


async def begin(message: Message, state: FSMContext, user: dict) -> None:
    await state.clear()
    await state.set_state(Setup.name)
    await message.answer(
        "👋 Привет! Я помогу держать в одном месте пары, смены, домашки и напоминания.\n\n"
        "Настройка займёт минуту. Как тебя называть?",
        reply_markup=choice_keyboard([(f"Оставить «{user['name']}»", "ob:name_keep")], 1))


@router.message(CommandStart())
async def start_cmd(message: Message, state: FSMContext, user: dict):
    if user["onboarded"]:
        await message.answer(f"С возвращением, {html.quote(user['name'])}! Жми ⭐ Важное или смотри /help. "
                             "Поменять настройки — /setup.", reply_markup=MENU)
        return
    await begin(message, state, user)


@router.message(Command("setup"))
async def setup_cmd(message: Message, state: FSMContext, user: dict):
    await begin(message, state, user)


@router.callback_query(Setup.name, F.data == "ob:name_keep")
async def name_keep(call: CallbackQuery, state: FSMContext, user: dict):
    await call.answer()
    await ask_study(call.message, state)


@router.message(Setup.name, F.text)
async def name_set(message: Message, state: FSMContext, user: dict):
    await store.update_user(user["user_id"], name=message.text.strip()[:40])
    await ask_study(message, state)


async def ask_study(message: Message, state: FSMContext) -> None:
    await state.set_state(Setup.study)
    await message.answer(
        "🎓 Откуда брать расписание учёбы?",
        reply_markup=choice_keyboard([("📊 Google-таблица", "ob:study_sheet"), ("✍️ Введу вручную", "ob:study_manual"),
                                      ("⏭ Без учёбы", "ob:study_none")], 1))


@router.callback_query(Setup.study, F.data.startswith("ob:study_"))
async def study_choice(call: CallbackQuery, state: FSMContext, user: dict):
    mode = call.data.split("_", 1)[1]
    await call.answer()
    await store.update_user(user["user_id"], study_mode=mode)
    if mode == "sheet":
        await state.set_state(Setup.univ_sheet)
        tpl = f"\nШаблон для копирования: {TEMPLATE_UNIV_SHEET_URL}" if TEMPLATE_UNIV_SHEET_URL else ""
        await call.message.answer(
            "Пришли ссылку на таблицу. Формат: столбец A — день недели, B — пары на неделе «плюс», C — на неделе «минус».\n"
            "Доступ: «Все, у кого есть ссылка — читатель»." + tpl)
    elif mode == "manual":
        await state.set_state(Setup.semester)
        await call.message.answer("Пары добавишь потом командой /schedule.\n"
                                  "Дата начала семестра — понедельник первой учебной недели (ДД.ММ.ГГГГ):")
    else:
        await ask_work(call.message, state)


@router.message(Setup.univ_sheet, F.text)
async def univ_sheet_set(message: Message, state: FSMContext, user: dict):
    sid = parse_sheet_id(message.text)
    if not sid:
        await message.answer("Не вижу ссылку на Google-таблицу. Пример: https://docs.google.com/spreadsheets/d/…/edit")
        return
    ok, why = await probe_sheet(sid)
    if not ok:
        await message.answer(f"Не смог прочитать таблицу ({html.quote(why)}). Проверь доступ «по ссылке» и пришли снова.")
        return
    await store.update_user(user["user_id"], univ_sheet_id=sid)
    await state.set_state(Setup.semester)
    await message.answer(f"✅ Таблица подключена ({why}).\n"
                         "Дата начала семестра — понедельник первой учебной недели (ДД.ММ.ГГГГ):")


@router.message(Setup.semester, F.text)
async def semester_set(message: Message, state: FSMContext, user: dict):
    m = re.fullmatch(r"\s*(\d{1,2})[.](\d{1,2})[.](\d{4})\s*", message.text or "")
    try:
        d = date(int(m.group(3)), int(m.group(2)), int(m.group(1))) if m else None
    except ValueError:
        d = None
    if not d:
        await message.answer("Формат: 01.09.2026")
        return
    await store.update_user(user["user_id"], semester_start=d.isoformat())
    await state.set_state(Setup.parity)
    await message.answer("Первая неделя семестра — какая?",
                         reply_markup=choice_keyboard([("➕ плюс", "ob:par_1"), ("➖ минус", "ob:par_0"),
                                                       ("Нет чередования", "ob:par_1")]))


@router.callback_query(Setup.parity, F.data.startswith("ob:par_"))
async def parity_set(call: CallbackQuery, state: FSMContext, user: dict):
    await call.answer()
    await store.update_user(user["user_id"], starts_plus=call.data.endswith("1"))
    await ask_work(call.message, state)


async def ask_work(message: Message, state: FSMContext) -> None:
    await state.set_state(Setup.work)
    await message.answer("💼 Есть график работы?",
                         reply_markup=choice_keyboard([("📊 Google-таблица", "ob:work_sheet"), ("✍️ Введу вручную", "ob:work_manual"),
                                                       ("⏭ Не работаю", "ob:work_none")], 1))


@router.callback_query(Setup.work, F.data.startswith("ob:work_"))
async def work_choice(call: CallbackQuery, state: FSMContext, user: dict):
    mode = call.data.split("_", 1)[1]
    await call.answer()
    await store.update_user(user["user_id"], work_mode=mode)
    if mode == "sheet":
        await state.set_state(Setup.work_sheet)
        tpl = f"\nШаблон: {TEMPLATE_WORK_SHEET_URL}" if TEMPLATE_WORK_SHEET_URL else ""
        await call.message.answer("Ссылка на график: в первой строке — числа месяца, в первых столбцах — фамилии, "
                                  "в ячейке — время смены (например «9-18») или «В»." + tpl)
    elif mode == "manual":
        await call.message.answer("Смены добавишь командой /schedule (пример: «смена 15.10 до 18:00»).")
        await ask_city(call.message, state)
    else:
        await ask_city(call.message, state)


@router.message(Setup.work_sheet, F.text)
async def work_sheet_set(message: Message, state: FSMContext, user: dict):
    sid = parse_sheet_id(message.text)
    if not sid:
        await message.answer("Не вижу ссылку на Google-таблицу.")
        return
    ok, why = await probe_sheet(sid)
    if not ok:
        await message.answer(f"Не смог прочитать таблицу ({html.quote(why)}).")
        return
    await store.update_user(user["user_id"], work_sheet_id=sid)
    await state.set_state(Setup.surname)
    await message.answer("✅ График подключён. Как записана твоя фамилия в графике?")


@router.message(Setup.surname, F.text)
async def surname_set(message: Message, state: FSMContext, user: dict):
    await store.update_user(user["user_id"], work_surname=message.text.strip()[:40])
    await ask_city(message, state)


async def ask_city(message: Message, state: FSMContext) -> None:
    await state.set_state(Setup.city)
    await message.answer("🌍 Город — для погоды в сводке:",
                         reply_markup=choice_keyboard([("⏭ Без погоды", "ob:city_skip")], 1))


@router.callback_query(Setup.city, F.data == "ob:city_skip")
async def city_skip(call: CallbackQuery, state: FSMContext, user: dict):
    await call.answer()
    await store.update_user(user["user_id"], city=None, lat=None, lon=None)
    await ask_address(call.message, state)


@router.message(Setup.city, F.text)
async def city_set(message: Message, state: FSMContext, user: dict):
    g = await geocode(message.text)
    if not g:
        await message.answer("Не нашёл такой город. Попробуй другое написание или нажми «Без погоды».")
        return
    name, lat, lon = g
    await store.update_user(user["user_id"], city=name, lat=lat, lon=lon)
    await message.answer(f"✅ {html.quote(name)}")
    await ask_address(message, state)


async def ask_address(message: Message, state: FSMContext) -> None:
    await state.set_state(Setup.address)
    await message.answer("📍 Адрес вуза для кнопки «Маршрут» (или пропусти):",
                         reply_markup=choice_keyboard([("⏭ Пропустить", "ob:addr_skip")], 1))


@router.callback_query(Setup.address, F.data == "ob:addr_skip")
async def addr_skip(call: CallbackQuery, state: FSMContext, user: dict):
    await call.answer()
    await finish(call.message, state, user)


@router.message(Setup.address, F.text)
async def addr_set(message: Message, state: FSMContext, user: dict):
    await store.update_user(user["user_id"], univ_address=message.text.strip()[:120])
    await finish(message, state, user)


async def finish(message: Message, state: FSMContext, user: dict) -> None:
    await state.clear()
    u = await store.update_user(user["user_id"], onboarded=True, active=True)
    await message.answer(
        f"🎉 Готово! Сводка будет приходить в {u['morning']}, план на завтра — в {u['evening']} (по Москве).\n"
        "Поменять: «Присылай сводку каждый день в 07:30».\n\n"
        "Домашка: <code>+ Матан - задачи 5-7 до 15.10</code>\n"
        "Напоминание: <code>Напомни завтра в 08:00 взять документы</code>\n"
        "Всё остальное — /help.", reply_markup=MENU)

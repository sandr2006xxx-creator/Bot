"""Объекты, которым нужен токен. Импортировать только после config.require_env()."""
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import KeyboardButton, ReplyKeyboardMarkup

from .config import BOT_TOKEN

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML, link_preview_is_disabled=True))
dp = Dispatcher()

BTN_IMPORTANT = "⭐ Важное"
BTN_MY = "🔔 Мои напоминания"
MENU = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text=BTN_IMPORTANT), KeyboardButton(text=BTN_MY)]],
                           resize_keyboard=True, is_persistent=True)

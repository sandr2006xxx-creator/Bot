"""Настройки. Секреты (BOT_TOKEN, OWNER_ID) — ТОЛЬКО из переменных окружения.
OWNER_ID = администратор (алерты, бэкапы, /admin). Личные параметры живут в таблице users."""
import os
from datetime import date, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
OWNER_ID = int((os.getenv("OWNER_ID") or "0").strip() or 0)


def require_env() -> None:
    missing = [n for n, v in (("BOT_TOKEN", BOT_TOKEN), ("OWNER_ID", OWNER_ID)) if not v]
    if missing:
        raise SystemExit("Не заданы переменные окружения: " + ", ".join(missing)
                         + ". Задай их в Amvera → проект → «Переменные» и перезапусти.")


# --- профиль владельца по умолчанию (только для миграции старой базы) ------
DEFAULT_PROFILE = {
    "name": os.getenv("OWNER_NAME", "Александр"),
    "work_sheet_id": os.getenv("WORK_SHEET_ID", "1xnV_2mq5pIsmIOsmcTQT1chryACExijUocN4u1QVwog"),
    "work_surname": os.getenv("WORK_SURNAME", "Тарасов"),
    "univ_sheet_id": os.getenv("UNIVER_SHEET_ID", "1iaCdX8WhTGQhD8qipg9H-LqjszBCJTdQ"),
    "semester_start": date(2026, 9, 1).isoformat(),
    "starts_plus": 0,
    "city": "Тверь", "lat": 56.8587, "lon": 35.9176,
    "univ_address": "Тверь, 2-я улица Грибоедова, 22",
}
TEMPLATE_UNIV_SHEET_URL = os.getenv("TEMPLATE_UNIV_SHEET_URL", "")
TEMPLATE_WORK_SHEET_URL = os.getenv("TEMPLATE_WORK_SHEET_URL", "")

# --- поведение --------------------------------------------------------------
MORNING_TIME = "07:00"
EVENING_TIME = "20:00"
COLD_THRESHOLD = 3
REMINDER_HORIZON = 14
CATCHUP = timedelta(hours=3)
SNOOZE_MIN = 30
MAX_MSG = 3800
PAGE_SIZE = 8
TICK_SECONDS = 30
BACKUP_TIME = "03:30"
BACKUP_KEEP = 7
BACKUP_TO_TELEGRAM = os.getenv("BACKUP_TO_TELEGRAM", "0") == "1"
SEND_BATCH = 20
SEND_BATCH_PAUSE = 1.0
MAX_TIMED_PER_USER = 200
MAX_HW_PER_USER = 200

# --- кэш (секунды) ----------------------------------------------------------
TTL_UNIVER = int(os.getenv("TTL_UNIVER", 6 * 3600))
TTL_WORK = int(os.getenv("TTL_WORK", 3600))
TTL_WEATHER = int(os.getenv("TTL_WEATHER", 20 * 60))

# --- пути и константы -------------------------------------------------------
TZ = ZoneInfo("Europe/Moscow")
DATA_DIR = Path("/data") if Path("/data").is_dir() and os.access("/data", os.W_OK) else Path(".")
DB_FILE = DATA_DIR / "bot.sqlite"
LEGACY_STATE_FILE = DATA_DIR / "state.json"
BACKUP_DIR = DATA_DIR / "backups"

DAYS_RU = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
DAYS_SHORT = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
MONTHS_GEN = ["января", "февраля", "марта", "апреля", "мая", "июня",
              "июля", "августа", "сентября", "октября", "ноября", "декабря"]

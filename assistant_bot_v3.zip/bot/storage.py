"""SQLite-хранилище, многопользовательское. Все выборки — с user_id.
Миграция: старые таблицы получают user_id = OWNER_ID, kv-ключи получают суффикс :OWNER_ID."""
import asyncio
import json
import logging
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .config import DB_FILE, DEFAULT_PROFILE, EVENING_TIME, LEGACY_STATE_FILE, MORNING_TIME, OWNER_ID
from .utils import now

log = logging.getLogger("bot.storage")

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (
  user_id INTEGER PRIMARY KEY, name TEXT, username TEXT,
  morning TEXT NOT NULL DEFAULT '07:00', evening TEXT NOT NULL DEFAULT '20:00',
  study_mode TEXT NOT NULL DEFAULT 'none',
  work_mode  TEXT NOT NULL DEFAULT 'none',
  univ_sheet_id TEXT, work_sheet_id TEXT, work_surname TEXT,
  semester_start TEXT, starts_plus INTEGER NOT NULL DEFAULT 0,
  city TEXT, lat REAL, lon REAL, univ_address TEXT,
  onboarded INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
  created TEXT, last_seen TEXT);
CREATE TABLE IF NOT EXISTS homework (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL DEFAULT %(o)d,
  subject TEXT NOT NULL, task TEXT NOT NULL,
  deadline TEXT, done INTEGER NOT NULL DEFAULT 0, created TEXT, done_at TEXT);
CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL DEFAULT %(o)d,
  title TEXT NOT NULL, date TEXT NOT NULL,
  done INTEGER NOT NULL DEFAULT 0, created TEXT, done_at TEXT);
CREATE TABLE IF NOT EXISTS timed (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL DEFAULT %(o)d,
  text TEXT NOT NULL, due TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', with_hw INTEGER NOT NULL DEFAULT 0,
  with_summary INTEGER NOT NULL DEFAULT 1, created TEXT, tries INTEGER NOT NULL DEFAULT 0, sent_at TEXT);
CREATE TABLE IF NOT EXISTS schedule (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
  kind TEXT NOT NULL, weekday INTEGER, parity TEXT, date TEXT,
  start TEXT, end TEXT, text TEXT NOT NULL);
""" % {"o": OWNER_ID}

INDEXES = """
CREATE INDEX IF NOT EXISTS idx_hw_user ON homework(user_id, done, deadline);
CREATE INDEX IF NOT EXISTS idx_rem_user ON reminders(user_id, done, date);
CREATE INDEX IF NOT EXISTS idx_timed_status ON timed(status, due);
CREATE INDEX IF NOT EXISTS idx_timed_user ON timed(user_id, status, due);
CREATE INDEX IF NOT EXISTS idx_sched_user ON schedule(user_id, kind, weekday, date);
"""

BOOL_COLS = {"done", "with_hw", "with_summary", "starts_plus", "onboarded", "active"}
USER_FIELDS = {"name", "username", "morning", "evening", "study_mode", "work_mode", "univ_sheet_id",
               "work_sheet_id", "work_surname", "semester_start", "starts_plus", "city", "lat", "lon",
               "univ_address", "onboarded", "active", "last_seen"}


def _row(r: Optional[sqlite3.Row]) -> Optional[dict]:
    if r is None:
        return None
    d = dict(r)
    for k in BOOL_COLS & d.keys():
        d[k] = bool(d[k])
    return d


class Store:
    def __init__(self, path: Path = DB_FILE) -> None:
        self.path = path
        self.conn: Optional[sqlite3.Connection] = None
        self._lock = asyncio.Lock()

    async def open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = await asyncio.to_thread(self._connect)
        await self._migrate_legacy()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.executescript(SCHEMA)
        self._migrate_multiuser(conn)
        conn.executescript(INDEXES)
        conn.commit()
        return conn

    @staticmethod
    def _migrate_multiuser(conn: sqlite3.Connection) -> None:
        """Однопользовательская база v2 → многопользовательская. Идемпотентно."""
        for table in ("homework", "reminders", "timed"):
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
            if "user_id" not in cols:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN user_id INTEGER NOT NULL DEFAULT {OWNER_ID}")
                log.info("Добавил user_id в %s", table)
        if conn.execute("SELECT 1 FROM users WHERE user_id=?", (OWNER_ID,)).fetchone() is None:
            times = conn.execute("SELECT value FROM kv WHERE key='times'").fetchone()
            t = json.loads(times[0]) if times else {}
            p = DEFAULT_PROFILE
            conn.execute(
                "INSERT INTO users(user_id, name, morning, evening, study_mode, work_mode, univ_sheet_id, "
                "work_sheet_id, work_surname, semester_start, starts_plus, city, lat, lon, univ_address, "
                "onboarded, created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?)",
                (OWNER_ID, p["name"], t.get("morning", MORNING_TIME), t.get("evening", EVENING_TIME),
                 "sheet", "sheet", p["univ_sheet_id"], p["work_sheet_id"], p["work_surname"],
                 p["semester_start"], p["starts_plus"], p["city"], p["lat"], p["lon"], p["univ_address"],
                 now().isoformat()))
            for key in ("sent", "awaiting", "after_shift"):
                r = conn.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
                if r:
                    conn.execute("INSERT OR REPLACE INTO kv(key, value) VALUES(?, ?)", (f"{key}:{OWNER_ID}", r[0]))
                    conn.execute("DELETE FROM kv WHERE key=?", (key,))
            conn.execute("DELETE FROM kv WHERE key='times'")
            log.info("Создал профиль владельца %s из config и kv", OWNER_ID)

    async def close(self) -> None:
        if self.conn:
            await asyncio.to_thread(self.conn.close)
            self.conn = None

    async def _run(self, fn, *args):
        async with self._lock:
            return await asyncio.to_thread(fn, *args)

    def _exec(self, sql: str, params: tuple = ()) -> int:
        cur = self.conn.execute(sql, params)
        self.conn.commit()
        return cur.lastrowid

    def _all(self, sql: str, params: tuple = ()) -> list[dict]:
        return [_row(r) for r in self.conn.execute(sql, params).fetchall()]

    def _one(self, sql: str, params: tuple = ()) -> Optional[dict]:
        return _row(self.conn.execute(sql, params).fetchone())

    async def execute(self, sql: str, params: tuple = ()) -> int:
        return await self._run(self._exec, sql, params)

    async def fetchall(self, sql: str, params: tuple = ()) -> list[dict]:
        return await self._run(self._all, sql, params)

    async def fetchone(self, sql: str, params: tuple = ()) -> Optional[dict]:
        return await self._run(self._one, sql, params)

    # ---------- key-value: глобальный и per-user ----------
    async def get(self, key: str, default: Any = None) -> Any:
        r = await self.fetchone("SELECT value FROM kv WHERE key=?", (key,))
        return json.loads(r["value"]) if r else default

    async def set(self, key: str, value: Any) -> None:
        await self.execute("INSERT INTO kv(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                           (key, json.dumps(value, ensure_ascii=False)))

    async def uget(self, uid: int, key: str, default: Any = None) -> Any:
        return await self.get(f"{key}:{uid}", default)

    async def uset(self, uid: int, key: str, value: Any) -> None:
        await self.set(f"{key}:{uid}", value)

    # ---------- пользователи ----------
    async def user(self, uid: int) -> Optional[dict]:
        return await self.fetchone("SELECT * FROM users WHERE user_id=?", (uid,))

    async def get_or_create_user(self, uid: int, name: str = "", username: str = "") -> dict:
        u = await self.user(uid)
        if u is None:
            await self.execute("INSERT INTO users(user_id, name, username, created, last_seen) VALUES(?,?,?,?,?)",
                               (uid, name or "друг", username, now().isoformat(), now().isoformat()))
            u = await self.user(uid)
        return u

    async def update_user(self, uid: int, **fields: Any) -> dict:
        fields = {k: (int(v) if isinstance(v, bool) else v) for k, v in fields.items() if k in USER_FIELDS}
        if fields:
            cols = ", ".join(f"{k}=?" for k in fields)
            await self.execute(f"UPDATE users SET {cols} WHERE user_id=?", (*fields.values(), uid))
        return await self.user(uid)

    async def active_users(self) -> list[dict]:
        return await self.fetchall("SELECT * FROM users WHERE active=1 AND onboarded=1 ORDER BY user_id")

    async def times(self, uid: int) -> dict:
        u = await self.user(uid)
        return {"morning": u["morning"], "evening": u["evening"]} if u else {"morning": MORNING_TIME, "evening": EVENING_TIME}

    async def set_time(self, uid: int, kind: str, hhmm: str) -> None:
        await self.update_user(uid, **{kind: hhmm})

    # ---------- домашки ----------
    async def pending_hw(self, uid: int) -> list[dict]:
        return await self.fetchall(
            "SELECT * FROM homework WHERE user_id=? AND done=0 ORDER BY deadline IS NULL, deadline, id", (uid,))

    async def add_hw(self, uid: int, subject: str, task: str, deadline: Optional[str]) -> dict:
        hw_id = await self.execute("INSERT INTO homework(user_id, subject, task, deadline, created) VALUES(?,?,?,?,?)",
                                   (uid, subject, task, deadline, now().isoformat()))
        return await self.fetchone("SELECT * FROM homework WHERE id=?", (hw_id,))

    async def hw_done(self, uid: int, hw_id: int) -> None:
        await self.execute("UPDATE homework SET done=1, done_at=? WHERE id=? AND user_id=?",
                           (now().isoformat(), hw_id, uid))

    # ---------- напоминания на дату ----------
    async def active_reminders(self, uid: int) -> list[dict]:
        return await self.fetchall("SELECT * FROM reminders WHERE user_id=? AND done=0 ORDER BY date, id", (uid,))

    async def add_reminder(self, uid: int, title: str, day: str) -> dict:
        rid = await self.execute("INSERT INTO reminders(user_id, title, date, created) VALUES(?,?,?,?)",
                                 (uid, title, day, now().isoformat()))
        return await self.fetchone("SELECT * FROM reminders WHERE id=?", (rid,))

    async def reminder_done(self, uid: int, rid: int) -> None:
        await self.execute("UPDATE reminders SET done=1, done_at=? WHERE id=? AND user_id=?",
                           (now().isoformat(), rid, uid))

    # ---------- напоминания на время ----------
    async def timed(self, uid: int, status: Optional[str] = None) -> list[dict]:
        if status:
            return await self.fetchall("SELECT * FROM timed WHERE user_id=? AND status=? ORDER BY due, id", (uid, status))
        return await self.fetchall("SELECT * FROM timed WHERE user_id=? ORDER BY due, id", (uid,))

    async def due_timed(self, before: datetime) -> list[dict]:
        return await self.fetchall("SELECT * FROM timed WHERE status='pending' AND due<=? ORDER BY due, id",
                                   (before.isoformat(),))

    async def find_timed(self, uid: int, rid: int) -> Optional[dict]:
        return await self.fetchone("SELECT * FROM timed WHERE id=? AND user_id=?", (rid, uid))

    async def add_timed(self, uid: int, text: str, due: datetime, with_hw: bool) -> dict:
        rid = await self.execute(
            "INSERT INTO timed(user_id, text, due, status, with_hw, with_summary, created, tries) VALUES(?,?,?,?,?,?,?,0)",
            (uid, text, due.isoformat(), "pending", int(with_hw), int(not with_hw), now().isoformat()))
        return await self.find_timed(uid, rid)

    async def update_timed(self, rid: int, **fields: Any) -> None:
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        vals = [int(v) if isinstance(v, bool) else v for v in fields.values()]
        await self.execute(f"UPDATE timed SET {cols} WHERE id=?", (*vals, rid))

    # ---------- ручное расписание ----------
    async def schedule(self, uid: int, kind: str) -> list[dict]:
        return await self.fetchall("SELECT * FROM schedule WHERE user_id=? AND kind=? ORDER BY weekday, date, start, id",
                                   (uid, kind))

    async def add_schedule(self, uid: int, kind: str, text: str, weekday: Optional[int] = None,
                           parity: Optional[str] = None, date: Optional[str] = None,
                           start: Optional[str] = None, end: Optional[str] = None) -> int:
        return await self.execute(
            "INSERT INTO schedule(user_id, kind, weekday, parity, date, start, end, text) VALUES(?,?,?,?,?,?,?,?)",
            (uid, kind, weekday, parity, date, start, end, text))

    async def clear_schedule(self, uid: int, kind: str, weekday: Optional[int] = None) -> None:
        if weekday is None:
            await self.execute("DELETE FROM schedule WHERE user_id=? AND kind=?", (uid, kind))
        else:
            await self.execute("DELETE FROM schedule WHERE user_id=? AND kind=? AND weekday=?", (uid, kind, weekday))

    # ---------- сервис ----------
    async def counts(self, uid: Optional[int] = None) -> dict:
        w, p = ("WHERE user_id=? AND", (uid,) * 5) if uid else ("WHERE", ())
        q = (f"SELECT (SELECT COUNT(*) FROM homework {w} done=0) hw, "
             f"(SELECT COUNT(*) FROM homework {w} done=1) hw_done, "
             f"(SELECT COUNT(*) FROM reminders {w} done=0) rem, "
             f"(SELECT COUNT(*) FROM timed {w} status='pending') timed_pending, "
             f"(SELECT COUNT(*) FROM timed {w} status='sent') timed_sent")
        return await self.fetchone(q, p)

    async def admin_stats(self) -> dict:
        return await self.fetchone(
            "SELECT (SELECT COUNT(*) FROM users) users, "
            "(SELECT COUNT(*) FROM users WHERE active=1 AND onboarded=1) active, "
            "(SELECT COUNT(*) FROM users WHERE created >= date('now','-7 day')) new_week")

    async def backup(self, dest: Path) -> Path:
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            dest.unlink()

        def _do():
            target = sqlite3.connect(dest)
            with target:
                self.conn.backup(target)
            target.close()
        await self._run(_do)
        return dest

    # ---------- миграция из state.json (v1) ----------
    async def _migrate_legacy(self) -> None:
        if await self.get("migrated_from_json") or not LEGACY_STATE_FILE.exists():
            return
        try:
            st = json.loads(LEGACY_STATE_FILE.read_text("utf-8"))
        except Exception:
            log.exception("state.json не читается — миграцию пропускаю")
            return

        def _do():
            c = self.conn
            for h in st.get("homework", []):
                c.execute("INSERT OR IGNORE INTO homework(id, user_id, subject, task, deadline, done, created) VALUES(?,?,?,?,?,?,?)",
                          (h.get("id"), OWNER_ID, h.get("subject", ""), h.get("task", ""), h.get("deadline"),
                           int(bool(h.get("done"))), now().isoformat()))
            for r in st.get("reminders", []):
                c.execute("INSERT OR IGNORE INTO reminders(id, user_id, title, date, done, created) VALUES(?,?,?,?,?,?)",
                          (r.get("id"), OWNER_ID, r.get("title", ""), r.get("date"), int(bool(r.get("done"))), now().isoformat()))
            for r in st.get("timed", []):
                c.execute("INSERT OR IGNORE INTO timed(id, user_id, text, due, status, with_hw, with_summary, created, tries, sent_at) "
                          "VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (r.get("id"), OWNER_ID, r.get("text", ""), r.get("due"), r.get("status", "pending"),
                           int(bool(r.get("with_hw"))), int(bool(r.get("with_summary", not r.get("with_hw")))),
                           r.get("created"), int(r.get("tries", 0)), r.get("sent_at")))
            t = st.get("times") or {}
            c.execute("UPDATE users SET morning=?, evening=? WHERE user_id=?",
                      (t.get("morning", MORNING_TIME), t.get("evening", EVENING_TIME), OWNER_ID))
            for key, val in (("sent", st.get("sent") or {}), ("awaiting", st.get("awaiting"))):
                c.execute("INSERT OR REPLACE INTO kv(key, value) VALUES(?,?)",
                          (f"{key}:{OWNER_ID}", json.dumps(val, ensure_ascii=False)))
            c.execute("INSERT OR REPLACE INTO kv(key, value) VALUES('migrated_from_json', ?)",
                      (json.dumps(now().isoformat()),))
            c.commit()
        await self._run(_do)
        shutil.move(LEGACY_STATE_FILE, LEGACY_STATE_FILE.with_suffix(".json.migrated"))
        log.info("Перенёс данные из state.json в %s", self.path)


store = Store()

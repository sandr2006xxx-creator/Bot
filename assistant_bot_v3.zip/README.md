# Ассистент — v3 (многопользовательский)

Бот для студентов, которые ещё и работают: пары, смены, домашки, напоминания, погода — каждому своё.

## Структура
```
main.py                   точка входа (Amvera: scriptName: main.py)
bot/config.py             настройки; BOT_TOKEN и OWNER_ID — только из env; OWNER_ID = администратор
bot/storage.py            SQLite: users, schedule, homework/reminders/timed с user_id; авто-миграция v2 → v3
bot/middleware.py         UserMiddleware — профиль пользователя в data["user"]
bot/data_sources.py       Google Sheets CSV, Open-Meteo, геокодер; кэш по URL (общие таблицы — один запрос)
bot/services.py           сводки / напоминания / ICS от профиля пользователя
bot/scheduler.py          APScheduler: tick по активным пользователям батчами, бэкап в 03:30
bot/handlers/onboarding.py  /start, /setup — пошаговая настройка (FSM)
bot/handlers/schedule.py    ручной ввод пар и смен (/schedule, /clear)
bot/handlers/admin.py       /admin, /broadcast
bot/handlers/…              commands / homework / reminders / callbacks / fallback
tests/                    python -m unittest discover -s tests
```

## Деплой на Amvera
1. **Сделай копию `/data/bot.sqlite`** (через консоль Amvera или /settings → бэкап у старой версии).
2. Переменные: `BOT_TOKEN`, `OWNER_ID` — обязательно (как раньше). Необязательно:
   `OWNER_NAME`, `WORK_SHEET_ID`, `WORK_SURNAME`, `UNIVER_SHEET_ID` — используются ТОЛЬКО при первом запуске,
   чтобы создать твой профиль из старых настроек; `TEMPLATE_UNIV_SHEET_URL`, `TEMPLATE_WORK_SHEET_URL` — ссылки на
   таблицы-шаблоны (доступ «читатель по ссылке»), которые бот покажет новым пользователям;
   `BACKUP_TO_TELEGRAM=1` — присылать файл базы админу (по умолчанию выключено: в базе чужие данные);
   `TTL_UNIVER`, `TTL_WORK`, `TTL_WEATHER`.
3. Залить всю папку: `main.py`, `bot/`, `tests/`, `requirements.txt`, `amvera.yml`.
4. Перезапустить. В логе должно быть «Добавил user_id в …» и «Создал профиль владельца …».
5. Проверить у себя `/settings`, затем `/start` с другого аккаунта.

## Миграция (автоматическая, идемпотентная)
- `homework`, `reminders`, `timed` получают колонку `user_id DEFAULT OWNER_ID`.
- Создаётся запись в `users` для OWNER_ID: режимы `sheet`/`sheet`, таблицы и фамилия из env/DEFAULT_PROFILE,
  время сводок из старого kv `times`.
- kv `sent`, `awaiting`, `after_shift` → `sent:<id>`, `awaiting:<id>`, `after_shift:<id>`.
- Старый `state.json` (v1), если ещё лежит в /data, тоже переносится.

## Как пользователь подключает расписание
- **Google-таблица**: формат тот же, что у тебя (A — день недели, B — пары «плюс», C — «минус»;
  график: числа месяца в первой строке, фамилии в первых столбцах, в ячейке время смены или «В»).
  Бот проверяет доступность таблицы при вводе ссылки.
- **Вручную**: `пн+ 09:00 Матан; 10:40 Физика` (знак — чётность недели, без знака — каждую неделю),
  `смена 15.10 до 18:00`, `выходной 16.10`; просмотр `/schedule`, очистка `/clear пн | учёба | работа`.
- **Без учёбы / без работы** — соответствующие блоки в сводке не показываются.

## Ограничения v3
- Одна таймзона (Europe/Moscow) для всех; поле `tz` в users можно добавить без миграции данных.
- FSM на MemoryStorage: незавершённая настройка сбрасывается при рестарте — пользователь жмёт /setup.
- Таблицы должны быть открыты «по ссылке»; приватные Google Sheets не поддерживаются.

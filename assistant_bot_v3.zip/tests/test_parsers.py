"""python -m unittest discover -s tests  (или pytest)."""
import unittest
from datetime import date, datetime
from unittest.mock import patch

from bot import parsers, utils
from bot.config import TZ
from bot.data_sources import schedule_from_rows, shift_info, week_name
from bot.utils import split_message

FIXED = datetime(2026, 10, 10, 10, 0, tzinfo=TZ)   # суббота


class ParseWhenTests(unittest.TestCase):
    def setUp(self):
        self.p1 = patch.object(parsers, "now", lambda: FIXED); self.p1.start()
        self.p2 = patch.object(utils, "now", lambda: FIXED); self.p2.start()

    def tearDown(self):
        self.p1.stop(); self.p2.stop()

    def test_relative_minutes(self):
        r = parsers.parse_when("Напомни через 40 минут сделать ДЗ")
        self.assertEqual(r["due"], datetime(2026, 10, 10, 10, 40, tzinfo=TZ))
        self.assertEqual(r["rest"], "сделать ДЗ")

    def test_half_hour(self):
        self.assertEqual(parsers.parse_when("напомни через полчаса позвонить")["due"].minute, 30)

    def test_tomorrow_clock(self):
        r = parsers.parse_when("Напомни завтра в 08:00 взять документы")
        self.assertEqual(r["due"], datetime(2026, 10, 11, 8, 0, tzinfo=TZ))
        self.assertTrue(r["used_tomorrow"])
        self.assertEqual(r["rest"], "взять документы")

    def test_clock_passed_rolls_to_tomorrow(self):
        r = parsers.parse_when("напомни в 9:00 выпить таблетку")
        self.assertEqual(r["due"].date(), date(2026, 10, 11))

    def test_weekday(self):
        r = parsers.parse_when("напомни в понедельник сдать отчёт")
        self.assertIsNone(r["due"])
        self.assertEqual(r["day"], date(2026, 10, 12))

    def test_date_dmy_and_month(self):
        self.assertEqual(parsers.parse_when("напомни 1.03 про ОСАГО")["day"], date(2027, 3, 1))
        self.assertEqual(parsers.parse_when("напомни 20 октября в 18.30 зайти")["due"],
                         datetime(2026, 10, 20, 18, 30, tzinfo=TZ))

    def test_bad_date(self):
        self.assertIsNotNone(parsers.parse_when("напомни 31.02 что-то")["error"])

    def test_in_days_with_clock(self):
        r = parsers.parse_when("напомни через 2 дня в 10:00 оплатить")
        self.assertEqual(r["due"], datetime(2026, 10, 12, 10, 0, tzinfo=TZ))

    def test_base_day(self):
        r = parsers.parse_when("в 18:30", base_day="2026-10-15")
        self.assertEqual(r["due"], datetime(2026, 10, 15, 18, 30, tzinfo=TZ))


class ParseDeadlineTests(unittest.TestCase):
    def setUp(self):
        self.p = patch.object(parsers, "now", lambda: FIXED); self.p.start()

    def tearDown(self):
        self.p.stop()

    def test_basic(self):
        self.assertEqual(parsers.parse_deadline("Матан - задачи 5-7 до 15.10"), ("Матан - задачи 5-7", "2026-10-15"))

    def test_rolls_year(self):
        self.assertEqual(parsers.parse_deadline("ОСАГО до 01.03")[1], "2027-03-01")

    def test_explicit_year(self):
        self.assertEqual(parsers.parse_deadline("ОСАГО до 01.03.2027")[1], "2027-03-01")

    def test_none(self):
        self.assertEqual(parsers.parse_deadline("без срока"), ("без срока", None))

    def test_mentions_hw(self):
        self.assertTrue(parsers.mentions_hw("сделать дз"))
        self.assertTrue(parsers.mentions_hw("Домашка по матану"))
        self.assertFalse(parsers.mentions_hw("поездка"))


class DataTests(unittest.TestCase):
    ROWS = [["ФИО", "1", "2", "3"], ["Иванов", "9-18", "В", ""], ["Тарасов И.", "В", "10:00-19:00", ""]]

    def test_shift(self):
        self.assertEqual(shift_info(self.ROWS, date(2026, 10, 1)), ("off", None))
        self.assertEqual(shift_info(self.ROWS, date(2026, 10, 2)), ("work", "19:00"))
        self.assertEqual(shift_info(self.ROWS, date(2026, 10, 3)), ("off", None))
        self.assertEqual(shift_info(self.ROWS, date(2026, 10, 9))[0], "error")
        self.assertEqual(shift_info(None, date(2026, 10, 1))[0], "error")

    def test_week_name(self):
        self.assertEqual(week_name(date(2026, 9, 1))[0], False)
        self.assertEqual(week_name(date(2026, 9, 8))[0], True)

    def test_schedule(self):
        rows = [["День", "плюс", "минус"], ["Понедельник", "Матан 9:00", "Физика 9:00"]]
        self.assertEqual(schedule_from_rows(rows, date(2026, 9, 7)), "Физика 9:00")   # минус
        self.assertEqual(schedule_from_rows(rows, date(2026, 9, 14)), "Матан 9:00")   # плюс
        self.assertEqual(schedule_from_rows(rows, date(2026, 9, 15)), "")
        self.assertIsNone(schedule_from_rows(None, date(2026, 9, 15)))

    def test_split_message(self):
        text = "\n\n".join("строка %d " % i * 50 for i in range(30))
        chunks = split_message(text, 500)
        self.assertTrue(all(len(c) <= 500 for c in chunks))
        self.assertEqual("\n\n".join(chunks).replace("\n\n", "\n"), text.replace("\n\n", "\n"))


if __name__ == "__main__":
    unittest.main()
